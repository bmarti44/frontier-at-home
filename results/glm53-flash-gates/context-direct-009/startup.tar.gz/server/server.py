#!/usr/bin/env python3
"""Start an optional, authenticated local GLM server under existing containment."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import secrets
import stat
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/home/bmarti44/.cache/glm53-flash')
RUNTIME=BASE/'native-runtime-002/runtime'


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def reuse_prepared_kernels(state):
    """Copy existing warm caches; keep preparation evidence untouched."""
    sources=[]
    for attempt in ('mla-preflight-001','kda-preflight-002','conv-preflight-001','indexer-preflight-003','sampling-preparation-003','server-bringup-001','server-bringup-007','server-bringup-008','server-bringup-012','server-bringup-019-context-sync','server-20260909-224317','server-20260910-051709','server-20260910-054432','server-20260910-065113'):
        source=BASE/attempt/'state'
        for subtree in ('triton','.cache/flashinfer','.cache/vllm/modelinfos','.cache/exllamav3/autotune','deep-gemm','.tilelang/cache'):
            if (source/subtree).exists():
                shutil.copytree(source/subtree,state/subtree,dirs_exist_ok=True)
        sources.append(source)
    for group in (state/'triton').rglob('__grp__*.json'):
        data=json.loads(group.read_text())
        children={}
        for name,value in data['child_paths'].items():
            old=Path(value)
            origin=next((root for root in sources if old.is_relative_to(root)),None)
            if origin is None:raise ValueError('unexpected prepared kernel child path')
            relocated=state/old.relative_to(origin)
            if not relocated.is_file() or sha(old)!=sha(relocated):raise ValueError('prepared kernel copy mismatch')
            children[name]=str(relocated)
        group.write_text(json.dumps({'child_paths':children})+'\n')


def launch_key(path):
    if path is None:return secrets.token_urlsafe(32)
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(descriptor) as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077:
            raise ValueError('API key file must be an owner-only regular file')
        value=stream.read(258).strip()
        if not 32<=len(value)<=256 or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-' for c in value):
            raise ValueError('invalid API key file')
        return value


def release_model_file_cache(launch):
    """Advise verified model files without rereading payloads before CUDA init."""
    model=Path(launch['arguments'][launch['arguments'].index('--model')+1])
    inventory_path=model/'inventory.json'
    if sha(inventory_path)!=launch['model_inventory']['sha256']:
        raise ValueError('model inventory changed before file-cache advice')
    inventory=json.loads(inventory_path.read_text())
    before=Path('/proc/meminfo').read_text()
    advised_bytes=0
    for row in inventory['files']:
        path=model/row['path']
        if path.parent!=model:
            raise ValueError('file-cache advice requires direct model children')
        descriptor=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        try:
            info=os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode) or info.st_size!=row['size_bytes']:
                raise ValueError('model file changed before file-cache advice')
            os.posix_fadvise(descriptor,0,0,os.POSIX_FADV_DONTNEED)
            advised_bytes+=info.st_size
        finally:
            os.close(descriptor)
    print(json.dumps({'event':'verified_model_file_cache_release',
        'files':len(inventory['files']),'advised_bytes':advised_bytes,
        'meminfo_before':before,'meminfo_after':Path('/proc/meminfo').read_text()}),flush=True)


def serve(directory):
    launch=json.loads((directory/'launch.json').read_text())
    if launch['environment'].get('GLM53_RELEASE_MODEL_FILE_CACHE')=='1':
        release_model_file_cache(launch)
    os.environ['VLLM_API_KEY']=(directory/'api-key').read_text().strip()
    sys.path.insert(0,str(directory/'lib'))
    sys.argv=['vllm',*launch['arguments']]
    runpy.run_module('vllm.entrypoints.openai.api_server',run_name='__main__')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start',action='store_true')
    parser.add_argument('--profile',help='Explicit experimental profile under configs/profiles')
    parser.add_argument('--host',help='Host configuration for the named profile')
    parser.add_argument('--status',action='store_true')
    parser.add_argument('--stop',action='store_true')
    parser.add_argument('--model',type=Path,default=BASE/'model-weights-001')
    parser.add_argument('--output',type=Path,default=BASE/('server-'+time.strftime('%Y%m%d-%H%M%S')))
    parser.add_argument('--port',type=int,default=8015)
    parser.add_argument('--preset',choices=('original','agent-fast'),default='original',help='agent-fast: unmeasured 64K-per-request, four-slot candidate with a smaller KV cache and larger prompt batches')
    parser.add_argument('--text-only',action=argparse.BooleanOptionalAction,default=False,help='Disable vision while retaining the same four-slot text geometry')
    parser.add_argument('--skip-mm-profiling',action=argparse.BooleanOptionalAction,default=True,help='Skip automatic media warm-up while retaining media support')
    parser.add_argument('--prefill-batch',type=int,choices=(128,256,512,1024,2048),help='Override prompt chunk size (original: 128; agent-fast: 512)')
    parser.add_argument('--long-prefill-token-threshold',type=int,choices=(0,32),default=0,help='Native per-request chunk cap for the four-slot context probe')
    parser.add_argument('--standard-cuda-allocator',action=argparse.BooleanOptionalAction,default=True,help='Avoid expandable virtual reservations under the existing address-space limit')
    parser.add_argument('--release-warmup-cache',action=argparse.BooleanOptionalAction,default=True,help='Release unused startup allocations before reserving the full KV cache')
    parser.add_argument('--prepared-flashinfer',action=argparse.BooleanOptionalAction,default=True,help='Use existing compiled FlashInfer libraries through its native cache provider')
    parser.add_argument('--skip-autotune',action=argparse.BooleanOptionalAction,default=True,help='Use native default FlashInfer tactics without optional startup tuning')
    parser.add_argument('--api-key-file',type=Path,help='Reuse an existing owner-only API key when replacing the local server')
    args=parser.parse_args()
    snapshot=None
    if args.profile:
        sys.path.insert(0,str(ROOT/'scripts/lib'))
        import glm53_profile as profile_api
        profile_api.reject_overrides(sys.argv[1:])
        if sum((args.start,args.status,args.stop)) != 1:parser.error('choose exactly one lifecycle action')
        if args.status or args.stop:
            profile_api.lifecycle_action(args.profile,'stop' if args.stop else 'status');return
        snapshot=profile_api.resolve_profile(args.profile,args.host,args.output.resolve())
        args.port=snapshot['port']
        args.model=Path(snapshot['argv'][snapshot['argv'].index('--model')+1])
    elif args.host or args.status or args.stop:
        parser.error('--host, --status and --stop require --profile')
    if snapshot:
        with profile_api.preparing_session(snapshot,args.output.resolve()) as session:
            profile_api.verify_artifacts(snapshot)
            launch(args,snapshot,session,profile_api)
    else: launch(args,None,None,None)


def launch(args,snapshot,session,profile_api):
    if not args.start:raise ValueError('explicit --start is required; this never changes the serving default')
    if args.port not in range(1024,65536) or args.port in (8010,8013,8014):raise ValueError('use a separate local development port')
    agent_fast=args.preset=='agent-fast'
    prefill_batch=args.prefill_batch if args.prefill_batch is not None else (512 if agent_fast else 128)
    # Keep margin above a quarter of the original reservation for recurrent
    # states and cache-page rounding. Native startup must validate capacity;
    # this candidate's four-slot fit and speed have not been measured.
    kv_cache_bytes=4294967296 if agent_fast else 9565304320
    model=args.model.resolve(); output=args.output.resolve()
    api_key=launch_key(args.api_key_file)
    inventory=json.loads((model/'inventory.json').read_text())
    for row in ([] if snapshot else inventory['files']):
        path=model/row['path']
        if path.parent!=model or path.is_symlink() or path.stat().st_size!=row['size_bytes'] or sha(path)!=row['sha256']:
            raise ValueError('model inventory mismatch')
    output.mkdir(parents=True,exist_ok=False); (output/'lib').mkdir(); (output/'state').mkdir()
    shutil.copyfile(ROOT/'scripts/lib/glm53_runtime_policy.py',output/'lib/glm53_runtime_policy.py')
    if args.prepared_flashinfer:
        shutil.copyfile(ROOT/'scripts/lib/glm53_flashinfer_cache.py',output/'lib/flashinfer_jit_cache.py')
    if args.release_warmup_cache:
        shutil.copyfile(ROOT/'scripts/lib/glm53_worker.py',output/'lib/glm53_worker.py')
    shutil.copyfile(ROOT/'scripts/38_guard_glm53_probe.py',output/'guard.py')
    shutil.copyfile(__file__,output/'server.py')
    reuse_prepared_kernels(output/'state')
    descriptor=os.open(output/'api-key',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(descriptor,'w') as key:key.write(api_key+'\n')
    profile=json.loads((ROOT/'configs/profiles/glm-5.3-flash/cuda-spark-128g-1m.json').read_text())
    arguments=[value.replace('{model}',str(model)).replace('{port}',str(args.port)) for value in profile['launch']['args'][4:]]
    arguments[arguments.index('--max-num-batched-tokens')+1]=str(prefill_batch)
    if agent_fast:arguments[arguments.index('--max-model-len')+1]='65536'
    if args.long_prefill_token_threshold:
        arguments+=['--long-prefill-token-threshold',str(args.long_prefill_token_threshold)]
    if not args.text_only:
        arguments[arguments.index('--limit-mm-per-prompt')+1]='{"image":{"count":4,"width":512,"height":512},"video":{"count":1,"num_frames":16,"width":512,"height":512}}'
    arguments+=['--load-format','instanttensor','--dtype','bfloat16','--enforce-eager',
                '--enable-chunked-prefill','--kv-cache-memory-bytes',str(kv_cache_bytes),
                '--mm-processor-cache-gb','0']
    if args.skip_autotune:arguments+=['--kernel-config','{"enable_flashinfer_autotune":false}']
    if args.release_warmup_cache:arguments+=['--worker-cls','glm53_worker.WarmupCleanupWorker']
    if args.text_only:arguments+=['--language-model-only']
    if args.skip_mm_profiling:arguments+=['--skip-mm-profiling']
    state=output/'state'
    environment={**profile['launch']['env'],'HOME':str(state),'LANG':'C.UTF-8',
        'PATH':f'{RUNTIME}/bin:/usr/local/cuda-13.0/bin:/usr/bin:/bin','CUDA_HOME':'/usr/local/cuda-13.0',
        'CUDA_VISIBLE_DEVICES':'0','VLLM_PLUGINS':'vllm_exl3','GLM53_EXL3_BF16_SHARD_FIX':'1',
        'MAX_JOBS':'2','NVCC_THREADS':'1','TOKENIZERS_PARALLELISM':'false',
        'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','CUDA_CACHE_DISABLE':'1','FLASHINFER_DISABLE_JIT':'1',
        'TRITON_CACHE_AUTOTUNING':'1',
        'TRITON_CACHE_DIR':str(state/'triton'),'DG_JIT_CACHE_DIR':str(state/'deep-gemm'),
        'DG_JIT_USE_NVRTC':'0','DG_JIT_NVCC_COMPILER':'/usr/local/cuda-13.0/bin/nvcc','DG_JIT_CPP_STANDARD':'20',
        'VLLM_SPARSE_INDEXER_MAX_LOGITS_MB':'512',
        'INSTANTTENSOR_BUFFER_SIZE':'1342177280','INSTANTTENSOR_CHUNK_SIZE':'8388608',
        'INSTANTTENSOR_CONCURRENCY':'1','INSTANTTENSOR_IO_DEPTH':'3','INSTANTTENSOR_BACKEND':'AIO'}
    if args.standard_cuda_allocator:environment['PYTORCH_CUDA_ALLOC_CONF']='expandable_segments:False'
    if snapshot:
        arguments=snapshot['argv'][4:]
        environment=snapshot['env']
        profile={'profile_id':snapshot['profile_id']}
        args.preset=snapshot['profile_id'].split('/')[-1]
        prefill_batch=int(arguments[arguments.index('--max-num-batched-tokens')+1])
        kv_cache_bytes=int(arguments[arguments.index('--kv-cache-memory-bytes')+1])
        (output/'profile-snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
    launch={'scope':'development bring-up; no model qualification or performance claim',
        'preset':args.preset,
        'start_unix':time.time(),'arguments':arguments,'environment':environment,
        'library_sources':[{'path':p.name,'sha256':sha(p)} for p in sorted((output/'lib').glob('*.py'))],
        'worker_source':{'sha256':sha(output/'lib/glm53_worker.py')} if args.release_warmup_cache else None,
        'model_inventory':{'sha256':sha(model/'inventory.json')},
        'python':{'sha256':sha(RUNTIME/'bin/python3')},
        'source':{'sha256':sha(output/'server.py')},'profile':profile['profile_id'],
        'safety':{'minimum_start_gib':110,'kill_floor_gib':18,'memory_high_gib':92,'memory_max_gib':94,'timeout_seconds':9000}}
    (output/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
    control={'HOME':'/home/bmarti44','USER':'bmarti44','LOGNAME':'bmarti44','LANG':'C.UTF-8','PATH':'/usr/bin:/bin',
        'XDG_RUNTIME_DIR':'/run/user/1000','DBUS_SESSION_BUS_ADDRESS':'unix:path=/run/user/1000/bus',
        'GLM_SAFE_RUN_AS_CURRENT_USER':'1','GLM_SAFE_MIN_START_GIB':'110','GLM_SAFE_KILL_FLOOR_GIB':'18',
        'GLM_SAFE_MEMORY_HIGH_GIB':'92','GLM_SAFE_TIMEOUT_S':'9000','GLM_SAFE_DONE_DIGESTS':'1'}
    command=['/usr/bin/bash',str(ROOT/'results/glm52-gates/harness/glm_cgroup_run.sh'),
        '--tag','glm53-dev-'+str(os.getpid()),'--','/usr/bin/env','-i',
        *(k+'='+v for k,v in sorted(environment.items())),str(RUNTIME/'bin/python3'),'-I','-B',
        str(output/'guard.py'),'--output',str(output/'identity'),'--',str(output/'server.py'),'--serve',str(output)]
    print(json.dumps({'event':'launch','port':args.port,'output':str(output),'preset':args.preset,
        'context_per_slot':int(arguments[arguments.index('--max-model-len')+1]),'slots':4,
        'prefill_batch':prefill_batch,'kv_cache_bytes':kv_cache_bytes}),flush=True)
    if snapshot:
        returncode=profile_api.run_contained(command,control,output,snapshot,session)
    else:
        with (output/'wrapper.log').open('w') as log:
            returncode=subprocess.run(command,env=control,stdout=log,stderr=subprocess.STDOUT).returncode
    (output/'exit.json').write_text(json.dumps({'exit_code':returncode,'time_unix':time.time()})+'\n')
    raise SystemExit(returncode)


if __name__=='__main__':
    if sys.argv[1:2]==['--serve']:serve(Path(sys.argv[2]))
    else:main()
