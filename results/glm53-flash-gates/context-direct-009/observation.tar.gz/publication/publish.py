"""Retain completed observation around the failed short-fixture preparation."""
from pathlib import Path
import ast,copy,gzip,hashlib,json,math,tarfile,time
R=Path('/home/bmarti44/spark-deepseek-v4-flash');B=Path.home()/'.cache/glm53-flash';O=B/'context-direct-009-observations';D=R/'results/glm53-flash-gates/context-direct-009'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
assert read(O/'swap-census-terminal.json')['exit_code']==0
validator=Path('/tmp/glm53-publish-heaptrim009.py');assert sha(validator)=='e431579c164a1734f115ce35c988c6d5fc3baac63a3d8bed872e3ce45e06d8f9'
node=next(n for n in ast.parse(validator.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='validate_census');ns={'math':math};exec(compile(ast.Module(body=[node],type_ignores=[]),'closed-census-validator','exec'),ns)
raw=(O/'swap-census/raw.jsonl').read_bytes();rows=[json.loads(x) for x in raw.splitlines()];counters=ns['validate_census'](rows)
checks=[]
for name in ['missing_row','duplicate_index','nonfinite_time','negative_counter','terminal_coverage','counter_reset']:
 bad=rows.copy()
 if name=='missing_row':bad.pop(30)
 elif name=='terminal_coverage':bad[-1]={**bad[-1],'completed_censuses':899}
 else:
  bad[30]=copy.deepcopy(bad[30])
  if name=='duplicate_index':bad[30]['index']=bad[29]['index']
  elif name=='nonfinite_time':bad[30]['before']['time_unix']=float('nan')
  elif name=='negative_counter':bad[30]['before']['pswpin']=-1
  else:bad[30]['before']['pswpin']-=1
 try:ns['validate_census'](bad)
 except (AssertionError,ValueError,TypeError,KeyError):checks.append({'mutation':name,'rejected':True})
 else:raise AssertionError(name)
identity=read(O/'swap-census/manifest.json')['observer'];p=Path('/proc',str(identity['pid']));assert not p.exists() or int((p/'stat').read_text().rsplit(')',1)[1].split()[19])!=identity['start_ticks']
baseline=read(O/'phase-before-freeze.json')['counters'];assert all(all(x[k]==baseline[k] for k in ['pswpin','pswpout']) and x['SwapTotal_kib']==x['SwapFree_kib']==0 for x in counters)
summary={**read(D/'startup-summary.json'),'observer':{'observation_integrity':'PASS','censuses':900,'raw_rows':len(rows),'duration_seconds':counters[-1]['time_unix']-counters[0]['time_unix'],'maximum_observation_gap_seconds':max((b['observed_ns']-a['observed_ns'])/1e9 for a,b in zip(rows,rows[1:])),'global_swap_deltas_from_broad_baseline':{k:counters[-1][k]-baseline[k] for k in ['pswpin','pswpout']},'minimum_available_kib':min(x['MemAvailable_kib'] for x in counters),'process_read_errors':sum('read_error' in p for row in rows[1:-1] for p in row['processes']),'observer_identity_no_longer_live':True,'malformed_controls_rejected':len(checks),'coverage_limit':'Structural validation does not imply complete process reads. Original startup hit its host floor before READY. Later observation includes post-run artifact checks and explicitly marked independent next-attempt preparation; these cannot revise FAIL.'},'formula':'Startup must complete READY with continuous host floor and all existing safeguards before requests. A floor kill fails the attempt; no direct requests were admitted.'}
save(O/'actual-raw-mutations.json',{'scope':'Malformed copies of actual rows; no replacement measurements','checks':checks,'validator_sha256':sha(validator)})
save(D/'summary.json',summary)
entries=[(p,'observations/'+p.relative_to(O).as_posix()) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='frozen-source-snapshot.tar.gz']+[(validator,'publication/closed-census-validator.py'),(Path(__file__),'publication/publish.py')]
with tarfile.open(D/'observation.tar.gz','w:gz') as t:
 for p,name in entries:t.add(p,arcname=name)
with tarfile.open(D/'observation.tar.gz') as t:
 for p,name in entries:assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha(p),name
(D/'raw.jsonl.gz').write_bytes(gzip.compress(raw,mtime=0))
manifest={'scope':summary['scope'],'source_revision':read(B/'qualification-freeze-002/manifest.json')['source_revision'],'files':[{'path':p.name,'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.iterdir()) if p.name!='manifest.json'],'observation_archive_members':[{'path':name,'size_bytes':p.stat().st_size,'sha256':sha(p)} for p,name in entries],'raw_uncompressed_sha256':hashlib.sha256(raw).hexdigest()}
save(D/'manifest.json',manifest)
(D/'README.md').write_text('# Direct009 startup: FAIL\n\nStartup crossed the unchanged18GiB host reserve beforeREADY or any test request.\nThe wrapper killed the process group, cleaned remaining descendants and exited15.\nThe terminal identity summary is absent. Subsequent observations verify no model\nprocesses or cgroup survive, memory recovered and defaults/proxy/guards unchanged.\n\nAll2,486 prepared kernel files and110 frozen source bindings remained unchanged;\nthe pinned runtime/model inventory check passed after termination. Whole-host and\ncgroup swap stayed zero. Preserve the originalFAIL despite these separate checks.\n\nThe completed900-census archive preserves every process-read error and its exact\ncoverage. A small evidence publisher overlapped final startup; its recorded peak\ndoes not establish causation. Later samples include postchecks and explicitly\nmarked preparation for the unchanged serialized replay. They do not reviseFAIL.\n\nNo direct-context requests, quality, throughput or new capability result exists.\n')
print(json.dumps({'verdict':summary['verdict'],'archive_members':len(entries),'observer':summary['observer']}),flush=True)
