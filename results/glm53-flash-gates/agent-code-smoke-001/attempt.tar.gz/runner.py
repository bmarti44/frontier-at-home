import hashlib,importlib.util,json,shutil,time,urllib.request
from pathlib import Path
repo=Path('/home/bmarti44/spark-deepseek-v4-flash');server=Path('/home/bmarti44/.cache/glm53-flash/server-20260909-201848')
out=Path('/home/bmarti44/.cache/glm53-flash/agent-code-smoke-001');out.mkdir(exist_ok=False)
path=repo/'scripts/31_bench_accuracy.py';spec=importlib.util.spec_from_file_location('bench',path);bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
pins,_=bench.load_pins();row=bench.load_jsonl('humaneval',pins)[0];runtime=bench.resolve_humaneval_runtime_digest()
body={'model':'glm-5.3-flash','messages':[{'role':'user','content':'Complete the following Python function. Return only the complete Python code, including imports and the function definition.\n\n'+row['prompt']}],'temperature':0,'seed':42,'max_tokens':512,'stream':True,'stream_options':{'include_usage':True}}
def save(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
save('request.json',body);save('fixture.json',row)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
save('manifest.json',{'scope':'one prospectively selected chat coding smoke; not the raw-completion HumanEval protocol, general accuracy, or paired fidelity qualification','selection':'first pinned HumanEval row, selected before request; tests and solution withheld from model','acceptance':'normal stop, nonempty code, unchanged repository extraction and pinned Docker tests exit zero','runtime':runtime,'files':[{'path':str(p),'sha256':sha(p)} for p in [path,repo/'evalsets/humaneval.jsonl',server/'launch.json',server/'server.py',out/'request.json',out/'fixture.json',Path(__file__)]]})
key=(server/'api-key').read_text().strip();answer='';finish=None;done=False;usage=None
with (out/'raw.jsonl').open('x') as raw:
 def event(**data):raw.write(json.dumps({'time_unix':time.time(),'monotonic_ns':time.monotonic_ns(),**data})+'\n');raw.flush()
 event(kind='start')
 req=urllib.request.Request('http://127.0.0.1:8015/v1/chat/completions',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=300) as response:
   event(kind='http',status=response.status)
   for line in response:
    if not line.startswith(b'data:'):continue
    value=line[5:].strip()
    if value==b'[DONE]':done=True;event(kind='done');break
    chunk=json.loads(value);event(kind='chunk',chunk=chunk)
    if chunk.get('usage'):usage=chunk['usage']
    for c in chunk.get('choices',[]):
     answer+=c.get('delta',{}).get('content') or ''
     if c.get('finish_reason'):finish=c['finish_reason']
 except Exception as e:event(kind='error',error=str(e));raise
 finally:event(kind='end')
save('completion.json',{'content':answer,'finish_reason':finish,'done':done,'usage':usage})
assert done and finish=='stop' and answer,'short or incomplete generation'
# Candidate executes only through the repository's pinned, networkless Docker sandbox.
passed,_,reason,execution=bench.run_humaneval(row,answer,out,'execution')
save('summary.json',{'scope':'single chat coding smoke only','task_id':row['task_id'],'verdict':'PASS' if passed else 'FAIL','reason':reason,'execution':execution,'usage':usage,'full_context_tested':False,'paired_fidelity_tested':False})
print(json.dumps({'verdict':'PASS' if passed else 'FAIL','task_id':row['task_id'],'reason':reason,'usage':usage}),flush=True)
if not passed:raise SystemExit(1)
