import importlib.util,json,sys,time,urllib.request
from pathlib import Path
root=Path(sys.argv[1]);out=root/'agent-timing';out.mkdir(exist_ok=False)
scorer=Path('scripts/48_probe_glm53_context.py').resolve()
spec=importlib.util.spec_from_file_location('context_scorer',scorer);api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
key=(root/'api-key').read_text().strip()
prompts=[
'Write a Python function that reads JSON Lines records, validates that each record has a nonempty string id and a finite numeric value, rejects duplicate ids, and returns the sum of values. Include clear error messages and five unittest cases. Explain the handling of malformed records.',
'Implement a Python retry helper for an HTTP client. Retry transient failures with capped exponential backoff, honor a total deadline, and never retry a non-idempotent operation automatically. Include tests using injected sleep and clock functions. Explain your design.'
]
results=[]
for i,prompt in enumerate(prompts):
 body={'model':'glm-5.3-flash','messages':[{'role':'user','content':prompt}],'temperature':0,'max_tokens':512,'stream':True,'stream_options':{'include_usage':True},'return_token_ids':True}
 (out/f'{i}-request.json').write_text(json.dumps(body,indent=2)+'\n')
 rows=[]
 with (out/f'{i}-raw.jsonl').open('x') as raw:
  def event(**data):
   row={'monotonic_ns':time.monotonic_ns(),'time_unix':time.time(),**data};rows.append(row);raw.write(json.dumps(row)+'\n');raw.flush()
  event(kind='start')
  try:
   req=urllib.request.Request('http://127.0.0.1:8015/v1/chat/completions',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=300) as response:
    event(kind='http',status=response.status)
    for line in response:
     if not line.startswith(b'data:'):continue
     value=line[5:].strip()
     if value==b'[DONE]':event(kind='done');break
     event(kind='chunk',chunk=json.loads(value))
  except Exception as error:
   event(kind='error',error=str(error),body=error.read().decode() if hasattr(error,'read') else None)
  event(kind='end')
 try:
  ids=next(r['chunk']['prompt_token_ids'] for r in rows if r.get('chunk',{}).get('prompt_token_ids') is not None)
  content,reasoning,usage,finish,first,terminal,rid,outputs=api.parse_stream(rows,ids)
  token_rows=[r for r in rows if any(c.get('token_ids') for c in r.get('chunk',{}).get('choices',[]))]
  assert len(outputs)>=128
  assert all(len(r['chunk']['choices'][0]['token_ids'])==1 for r in token_rows),'batched delivery cannot give individual token timestamps'
  seconds=(token_rows[-1]['monotonic_ns']-token_rows[0]['monotonic_ns'])/1e9
  result={'case':i,'verdict':'PASS','usage':usage,'finish_reason':finish,'decode_tokens_per_second':(len(outputs)-1)/seconds,'ttft_seconds':(first-rows[0]['monotonic_ns'])/1e9,'decode_seconds':seconds,'output_tokens':len(outputs),'content':content,'reasoning':reasoning}
 except Exception as error:result={'case':i,'verdict':'FAIL','error':str(error)}
 results.append(result)
 (out/'summary.json').write_text(json.dumps({'scope':'development candidate timing only; not qualified production performance or task-quality acceptance','formula':'(N-1) / ((last_token_ns-first_token_ns)/1e9), N >=128; each timestamp must carry one token','cases':results},indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('content','reasoning')}),flush=True)
 if result['verdict']!='PASS':raise SystemExit(1)
