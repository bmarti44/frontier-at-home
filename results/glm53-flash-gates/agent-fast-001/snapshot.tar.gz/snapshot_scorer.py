import hashlib,io,json,re,subprocess,tarfile,time
from pathlib import Path
src=Path('/home/bmarti44/.cache/glm53-flash/server-20260909-201848')
dst=Path('results/glm53-flash-gates/agent-fast-001');dst.mkdir(exist_ok=False)
watch=Path('/home/bmarti44/.local/state/glm52-crashlog/20260909-202036-glm53-dev-1655918')
secret=(src/'api-key').read_bytes().strip()
paths=[(p.name,p) for p in src.iterdir() if p.is_file() and p.name!='api-key']
for sub in ('identity','lib','agent-timing'):
 paths += [(str(p.relative_to(src)),p) for p in (src/sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [('watchdog/'+p.name,p) for p in watch.iterdir() if p.is_file()]
paths += [('snapshot_scorer.py',Path(__file__)),('timing_client.py',Path('/tmp/glm53-agent-timing.py'))]
for name in ('first_response.py','feature_smoke.py'):
 paths.append(('scorers/'+name,Path('results/glm53-flash-gates/bringup-harness')/name))
paths.append(('scorers/context_stream.py',Path('scripts/48_probe_glm53_context.py')))
rows=[];captured={}
with tarfile.open(dst/'snapshot.tar.gz','w:gz') as archive:
 for name,p in paths:
  data=p.read_bytes();assert secret not in data
  captured[name]=data;rows.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)})
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
def read(name):return json.loads(captured[name])
first=read('first-response-summary.json');tool=read('tool-smoke-response.json')['response']['choices'][0]
slots=[read(f'slot-{i}-response.json') for i in range(2,6)]
launch=read('launch.json');args=launch['arguments'];val=lambda flag:args[args.index(flag)+1]
mem=[int(v) for v in re.findall(r'mem_avail_kb=(\d+)',captured['watchdog/samples.log'].decode())]
swap=[int(v) for v in re.findall(r'cgroup_swap_current_bytes=(\d+)',captured['watchdog/samples.log'].decode())]
state=json.loads(subprocess.check_output(['scripts/52_engine_switch.sh','status','--json'],text=True))
unit='glm52-glm53-dev-1655918-1657188.service'
unit_state=subprocess.check_output(['systemctl','--user','is-active',unit],text=True).strip()
checks={'authenticated_chat':first['completed'] and first['answer']=='2 + 2 equals 4.','unauthenticated_rejection':first['authentication_rejection']==401,'tool_arguments':tool['finish_reason']=='tool_calls' and tool['message']['tool_calls'][0]['function']['name']=='get_weather' and json.loads(tool['message']['tool_calls'][0]['function']['arguments'])=={'city':'Paris'},'four_completed_requests':all(r['response']['choices'][0]['finish_reason']=='stop' and str(2*n) in r['response']['choices'][0]['message']['content'] for n,r in zip(range(2,6),slots)),'four_client_requests_overlap':max(r['start'] for r in slots)<min(r['end'] for r in slots),'memory_floor':min(mem)>=18*1048576,'no_cgroup_swap':max(swap)==0,'default_unchanged':state['active_profile']=='qwen38-1m','unit_active':unit_state=='active','preset':launch['preset']=='agent-fast' and val('--max-model-len')=='65536' and val('--max-num-seqs')=='4' and val('--kv-cache-memory-bytes')=='4294967296' and val('--max-num-batched-tokens')=='512'}
for name,expected in [('images4-smoke','red, green, blue, yellow'),('video-smoke','blue'),('tool-roundtrip','21')]:
 choice=read(name+'-response.json')['response']['choices'][0];checks[name]=choice['finish_reason']=='stop' and expected in (choice['message']['content'] or '').lower()
summary={'scope':'development serving snapshot only; not production, capacity or fidelity qualification','verdict':'PASS' if all(checks.values()) else 'FAIL','snapshot_unix':time.time(),'checks':checks,'capacity':{'configured_tokens_per_request':65536,'configured_slots':4,'full_context_tested':False},'memory_low_gib':min(mem)/1048576,'memory_formula':'minimum externally sampled MemAvailable_kB / 1048576','cgroup_swap_peak_bytes':max(swap),'server_lifecycle':'live snapshot; terminal outcome not observed; 9000-second watchdog timeout','run_directory':str(src),'unit':unit,'recorded_default':state,'production_performance':'not yet measured','timing_evidence':'agent-timing in archive; case 0 isolated, case 1 excluded from isolated speed comparison due to overlapping media request; both ended at requested output limit'}
(dst/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
a=dst/'snapshot.tar.gz';(dst/'manifest.json').write_text(json.dumps({'scope':'per-file live snapshot, not a frozen confirmation','archive':{'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'size_bytes':a.stat().st_size},'files':rows},indent=2)+'\n')
(dst/'README.md').write_text('''# Agent preset: basic serving PASS

The optional 64K-per-request, four-slot preset started and passed authenticated
chat, rejection without authentication, correct tool arguments, a tool-result
round trip, four overlapping requests, four images in order and a 16-frame video.
Media fixtures were 224x224. No external weather service was called.

The same model weights are used with a 4 GiB KV reservation and 512-token prompt
batches. The full 64K context and model fidelity have not been qualified. The
original million-token experiment remains available and its failure is preserved.
Qwen remains the recorded default. This is a live snapshot, not a terminal result.

The archive contains raw stream timestamps, requests/responses, launch settings,
identity observations, memory samples and scorers. It excludes the private API
key and warm caches. Short development timing measurements are preserved inside
`agent-timing/`; the second case overlapped a media request and is excluded from
isolated speed comparisons. Both coding responses reached their requested token
limit, so they do not establish completed coding-task quality. Qualified
production performance remains not yet measured.
''')
assert all(checks.values()),summary
print(json.dumps(summary,indent=2))
