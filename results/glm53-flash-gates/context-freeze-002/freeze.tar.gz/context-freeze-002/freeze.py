import hashlib,json,shutil,subprocess,time
from pathlib import Path
R=Path('/home/bmarti44/spark-deepseek-v4-flash');B=Path('/home/bmarti44/.cache/glm53-flash');old=B/'context-freeze-001';out=B/'context-freeze-002';server=B/'server-bringup-014-context';out.mkdir();(out/'code/scripts').mkdir(parents=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
previous=json.loads((old/'manifest.json').read_text())
for row in previous['files']:
 p=Path(row['path']);assert p.stat().st_size==row['size_bytes'] and sha(p)==row['sha256'],str(p)
for name,root in [('runtime',B/'native-runtime-002/runtime'),('model',B/'model-weights-001')]:
 data=json.loads((old/(name+'-identities.json')).read_text())
 for rel,expected in data.items():
  s=(root/rel).stat();assert [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]==expected,(name,rel)
 shutil.copyfile(old/(name+'-identities.json'),out/(name+'-identities.json'))
shutil.copyfile(old/'fetch-randomness.py',out/'fetch-randomness.py');shutil.copyfile(old/'code/scripts/103_verify_drand_receipt_bundle.mjs',out/'code/scripts/103_verify_drand_receipt_bundle.mjs');shutil.copyfile(__file__,out/'freeze.py')
cache=[{'path':str(p.relative_to(server/'state')),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((server/'state').rglob('*')) if p.is_file()];(out/'kernel-cache-inventory.json').write_text(json.dumps({'schema_version':1,'files':cache},indent=2)+'\n')
paths=[Path(row['path']) for row in previous['files']]+[old/'manifest.json',server/'launch.json',server/'server.py',server/'guard.py',server/'launch-frozen.py',R/'results/glm52-gates/harness/glm_cgroup_run.sh',R/'results/glm52-gates/harness/glm_safe_run.sh',out/'freeze.py',out/'fetch-randomness.py',out/'code/scripts/103_verify_drand_receipt_bundle.mjs',out/'kernel-cache-inventory.json']+list((server/'lib').glob('*.py'))
files=[{'path':str(p),'sha256':sha(p),'size_bytes':p.stat().st_size} for p in dict.fromkeys(paths)]
m={'scope':'prepared direct context candidate; fixture construction precedes model launch','source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'server_root':str(server),'files':files,'runtime_files_verified':previous['runtime_files_verified'],'model_files_verified':previous['model_files_verified'],'hash_basis':'fresh whole-file runtime/model verification incontext-freeze001; all frozen hashes and file identities revalidated unchanged here','cache_files':len(cache),'frozen_at_unix':time.time()};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'frozen_at_unix':m['frozen_at_unix'],'cache_files':len(cache),'unchanged_runtime_and_model':True}),flush=True)
