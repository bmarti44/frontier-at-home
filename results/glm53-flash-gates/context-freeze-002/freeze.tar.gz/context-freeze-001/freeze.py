import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/bmarti44/spark-deepseek-v4-flash');BASE=Path('/home/bmarti44/.cache/glm53-flash');SERVER=BASE/'server-bringup-013-context';OUT=BASE/'context-freeze-001';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts/lib'))
from glm53_contract import verify_inventory,strict_json,sha256_file
(OUT/'code/scripts').mkdir(parents=True)
shutil.copyfile(ROOT/'scripts/103_verify_drand_receipt_bundle.mjs',OUT/'code/scripts/103_verify_drand_receipt_bundle.mjs')
shutil.copyfile(BASE/'indexer-preflight-003/fetch-randomness.py',OUT/'fetch-randomness.py')
shutil.copyfile(__file__,OUT/'freeze.py')
print('Verifying packaged runtime',flush=True)
runtime=BASE/'native-runtime-002/runtime';inventory=BASE/'native-runtime-002/inventory.json';identities=verify_inventory(runtime,strict_json(inventory));(OUT/'runtime-identities.json').write_text(json.dumps(identities)+'\n')
print('Verifying selected model bytes',flush=True)
model=BASE/'model-weights-001';mi=strict_json(model/'inventory.json');mi_ids={}
for row in mi['files']:
 p=model/row['path'];a=p.stat();assert not p.is_symlink() and p.parent==model and a.st_size==row['size_bytes'] and sha256_file(p)==row['sha256'];b=p.stat();assert (a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns);mi_ids[row['path']]=[a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns]
(OUT/'model-identities.json').write_text(json.dumps(mi_ids)+'\n')
cache=[]
for p in sorted((SERVER/'state').rglob('*')):
 if p.is_file():cache.append({'path':str(p.relative_to(SERVER/'state')),'size_bytes':p.stat().st_size,'sha256':sha256_file(p)})
(OUT/'kernel-cache-inventory.json').write_text(json.dumps({'schema_version':1,'files':cache},indent=2)+'\n')
paths=[ROOT/'scripts/48_probe_glm53_context.py',ROOT/'scripts/57_dsv4_context_probe.py',ROOT/'scripts/tests/test_glm53_context_probe.py',ROOT/'fixtures/ctx-32k.txt',ROOT/'configs/profiles/glm-5.3-flash/cuda-spark-128g-1m.json',ROOT/'scripts/lib/glm53_contract.py',SERVER/'launch.json',SERVER/'server.py',SERVER/'guard.py',model/'inventory.json',inventory,runtime/'bin/python3',Path('/home/bmarti44/.nvm/versions/node/v22.22.2/bin/node'),OUT/'freeze.py',OUT/'fetch-randomness.py',OUT/'code/scripts/103_verify_drand_receipt_bundle.mjs',OUT/'runtime-identities.json',OUT/'model-identities.json',OUT/'kernel-cache-inventory.json']+list((SERVER/'lib').glob('*.py'))
manifest={'scope':'direct aggregate context candidate freeze, before public fixture seed','frozen_at_unix':time.time(),'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'server_root':str(SERVER),'runtime_files_verified':len(identities),'model_files_verified':len(mi_ids),'cache_files':len(cache),'files':[{'path':str(p),'sha256':sha256_file(p),'size_bytes':p.stat().st_size} for p in paths],'seed_rule':'four slot seeds derived from SHA256(public randomness + slot); existing BLS-verified post-freeze drand receipt'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'frozen_at_unix':manifest['frozen_at_unix'],'runtime_files':len(identities),'model_files':len(mi_ids),'cache_files':len(cache)}),flush=True)
