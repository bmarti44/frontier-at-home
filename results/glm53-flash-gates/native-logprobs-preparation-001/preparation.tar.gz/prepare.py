"""Fetch one non-final native reference window for probability plumbing only."""
import ast,hashlib,json,struct,time,urllib.request
from pathlib import Path
out=Path(__file__).resolve().parent;base=out.parent/'reference-audit-001'
def read(p):return json.loads(p.read_text())
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
api=read(base/'brandon-api.json');panel=read(base/'brandon/calibration/panel-v1/panel.json');manifest=read(base/'brandon/logits/full-panel/full-panel-manifest.json')
window=next(r for r in panel['windows'] if r['window_id']=='fit-0000');logit=next(r for r in manifest['logit_files'] if r['window_id']==window['window_id']);assert window['role']==logit['role']=='fit' and window['token_ids_sha256']==logit['token_ids_sha256']
root='https://huggingface.co/datasets/'+api['id']+'/resolve/'+api['sha']+'/'
records=[]
for name,remote,expected,size in [('tokens.npy','calibration/panel-v1/arrays/fit-0000.tokens.npy',window['token_ids_sha256'],None),('teacher.safetensors',logit['path'],logit['sha256'],logit['bytes'])]:
 path=out/name;start=time.time();h=hashlib.sha256();count=0
 with urllib.request.urlopen(root+remote,timeout=60) as response,path.open('xb') as f:
  while data:=response.read(1048576):h.update(data);count+=len(data);f.write(data)
 assert h.hexdigest()==expected and (size is None or count==size),(name,count)
 records.append({'path':name,'source_url':root+remote,'sha256':h.hexdigest(),'size_bytes':count,'started_unix':start,'completed_unix':time.time()});print(name,count,'verified',flush=True)
with (out/'tokens.npy').open('rb') as f:
 assert f.read(8)==b'\x93NUMPY\x01\x00';header=ast.literal_eval(f.read(struct.unpack('<H',f.read(2))[0]).decode());assert header=={'descr':'<i4','fortran_order':False,'shape':(2048,)};data=f.read();assert len(data)==8192;ids=list(struct.unpack('<2048i',data));assert all(0<=i<manifest['vocab_size'] for i in ids)
payload={'model':'glm-5.3-flash','prompt':ids,'add_special_tokens':False,'prompt_logprobs':1,'return_token_ids':True,'n':1,'max_tokens':1,'stream':False,'temperature':0}
(out/'request.json').write_text(json.dumps(payload)+'\n')
record={'scope':'one non-final fit window; native API alignment diagnostic only, never100-case qualification','reference_revision':api['sha'],'window':window,'logits':logit,'vocab_size':manifest['vocab_size'],'files':records,'request_sha256':digest(out/'request.json'),'sources':{str(p):digest(p) for p in [Path(__file__),base/'brandon-api.json',base/'brandon/calibration/panel-v1/panel.json',base/'brandon/logits/full-panel/full-panel-manifest.json']}}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print('native reference preparation complete',flush=True)
