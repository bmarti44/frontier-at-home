"""CPU-only native teacher reduction; one fit window, no quality verdict."""
import hashlib,json,math,struct
from pathlib import Path
import numpy as np
out=Path(__file__).resolve().parent
manifest=json.loads((out/'manifest.json').read_text());request=json.loads((out/'request.json').read_text());ids=request['prompt'];vocab=manifest['vocab_size']
assert len(ids)==2048 and request['add_special_tokens'] is False
source=out/'teacher.safetensors'
with source.open('rb') as f:
 assert hashlib.file_digest(f,'sha256').hexdigest()==manifest['logits']['sha256']
with source.open('rb') as f,(out/'teacher-positions.jsonl').open('x') as raw:
 n=struct.unpack('<Q',f.read(8))[0];assert 0<n<1048576
 header=json.loads(f.read(n));tensors={k:v for k,v in header.items() if k!='__metadata__'}
 assert len(tensors)==1
 name,tensor=next(iter(tensors.items()));assert tensor['dtype']=='F32' and tensor['shape']==[2047,vocab]
 assert tensor['data_offsets']==[0,2047*vocab*4] and source.stat().st_size==8+n+2047*vocab*4
 nlls=[];correct=0
 for position,target in enumerate(ids[1:],1):
  data=f.read(vocab*4);assert len(data)==vocab*4
  values=np.frombuffer(data,dtype='<f4').astype(np.float64);assert np.isfinite(values).all()
  top=int(values.argmax());peak=float(values[top]);lse=peak+math.log(float(np.exp(values-peak).sum(dtype=np.float64)));truth=float(values[target]);nll=lse-truth;assert math.isfinite(nll) and nll>=0
  nlls.append(nll);correct+=top==target
  raw.write(json.dumps({'position':position,'target_id':target,'top1_id':top,'target_logit':truth,'logsumexp':lse,'nll':nll},allow_nan=False)+'\n')
 assert not f.read(1)
summary={'scope':'native teacher metrics for one non-final fit window; diagnostic only','tokens':len(nlls),'nll_sum':math.fsum(nlls),'top1_correct':correct,'formula':'NLL = log(sum(exp(full-vocabulary FP32 logits))) - target logit, evaluated with stable FP64 accumulation; top1 is first argmax','alignment':'teacher rows0..2046 predict input positions1..2047','source_tensor':name}
(out/'teacher-summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');print(json.dumps(summary),flush=True)
