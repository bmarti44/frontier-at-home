"""One existing native prompt-logprob request, only after the context run is idle."""
import hashlib,json,re,sys,time,urllib.request
from pathlib import Path
if sys.flags.optimize:
 raise RuntimeError("Native capture checks require assertions; optimized Python is forbidden")
out=Path(__file__).resolve().parent;repo=Path('/home/bmarti44/spark-deepseek-v4-flash');server=out.parent/'server-bringup-014-context'
sys.path.insert(0,str(repo/'scripts/lib'))
from glm53_contract import strict_json
from glm53_prompt_metrics import reduce_prompt_response
manifest=strict_json(out/'manifest.json');payload=strict_json(out/'request.json');launch=strict_json(server/'launch.json');args=launch['arguments']
assert args[args.index('--logprobs-mode')+1]=='raw_logprobs'
assert hashlib.sha256((out/'request.json').read_bytes()).hexdigest()==manifest['request_sha256']
key=(server/'api-key').read_text().strip();headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}
base='http://127.0.0.1:8015'
with urllib.request.urlopen(urllib.request.Request(base+'/metrics',headers=headers),timeout=10) as r:metrics=r.read().decode()
for name in ('num_requests_running','num_requests_waiting'):
 matches=re.findall(r'^vllm:'+name+r'\{[^\n]*\} ([^\n]+)$',metrics,re.M);assert len(matches)==1 and float(matches[0])==0,'context/server is still busy'
files=[Path(__file__),out/'manifest.json',out/'request.json',out/'teacher-summary.json',out/'reduce_teacher.py',repo/'scripts/lib/glm53_prompt_metrics.py',repo/'scripts/lib/glm53_contract.py',server/'launch.json']
binding={'scope':'one non-final native probability diagnostic; no fidelity qualification','frozen_unix':time.time(),'files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'capture-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
start=time.time();request=urllib.request.Request(base+'/v1/completions',data=json.dumps(payload).encode(),headers=headers)
with urllib.request.urlopen(request,timeout=300) as r,(out/'candidate-response.json').open('xb') as f:data=r.read();f.write(data)
end=time.time();candidate=reduce_prompt_response(strict_json(out/'candidate-response.json'),payload['prompt'],'glm-5.3-flash',manifest['vocab_size']);teacher=strict_json(out/'teacher-summary.json');assert candidate['tokens']==teacher['tokens']==2047
summary={'scope':'one non-final fit window, native probability alignment diagnostic only','capture_start_unix':start,'capture_end_unix':end,'alignment':'PASS','candidate':candidate,'teacher':teacher,'delta_nll':(candidate['nll_sum']-teacher['nll_sum'])/2047,'top1_accuracy_loss_percentage_points':100*(teacher['top1_correct']-candidate['top1_correct'])/2047,'quality_qualification':'NO_RESULT: one non-final window is not100 native qualification cases','performance':'not yet measured'}
(out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');print(json.dumps(summary),flush=True)
