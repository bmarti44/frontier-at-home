import importlib.util,json,sys,tempfile
from pathlib import Path
source=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/context-scheduler-003/adapter.py');spec=importlib.util.spec_from_file_location('review_context_adapter',source);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
with tempfile.TemporaryDirectory() as d:
 root=Path(d);server=root/'wrong-server';server.mkdir();(server/'launch.json').write_text(json.dumps({'arguments':['--max-model-len','262144','--max-num-seqs','4','--max-num-batched-tokens','128','--long-prefill-token-threshold','32','--no-enable-prefix-caching']}))
 (root/'manifest.json').write_text(json.dumps({'files':[{'path':str(p),'size_bytes':p.stat().st_size,'sha256':a.probe.sha(p)} for p in a.SOURCES]}))
 direct_rejected=False
 try:a.probe.launch_check(server)
 except ValueError:direct_rejected=True
 assert direct_rejected
 calls=[];a.short.main=lambda out,server:(calls.append(str(server)) or 0)
 sys.argv=[str(source),'short','--frozen',str(root),'--output',str(root/'out'),'--server',str(server)]
 result=a.main();assert result==0 and calls
 record={'scope':'Caller dispatch only; closed short request routine replaced by a recording stub, no network call','source_sha256':a.probe.sha(source),'wrong_128_32_launch_rejected_by_selected_validator':direct_rejected,'short_delegate_called_with_wrong_launch':bool(calls),'adapter_return_code':result}
path=Path('/home/bmarti44/.cache/glm53-flash/context-scheduler-003-review-controls/short-dispatch-result.json');path.write_text(json.dumps(record,indent=2)+'\n');print(path.read_text())
