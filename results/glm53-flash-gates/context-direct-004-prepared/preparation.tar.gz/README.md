# Exact-input CUDA failure-localization replay: prepared, not run

The four request bodies, retrieval fixtures and input-token lists are copied
byte-for-byte from context-direct-003 and verified against its manifest. Each
request has 250,128 input tokens. The only native environment change is
`CUDA_LAUNCH_BLOCKING=1`; serving arguments, model and scorer remain unchanged.
Output-directory paths are relocated. A fresh audit found 251 changed runtime
bytecode cache files out of 61,353 files; sources and native binaries matched.
See `runtime-byte-audit.json`. The runtime is not byte-for-byte frozen.

This deliberately reuses the failed inputs to localize the CUDA error. It is
not a fresh-randomness confirmation or qualified production-performance run.
No request has been sent and no outcome is claimed.

Prepared server directory:
`/home/bmarti44/.cache/glm53-flash/server-bringup-019-context-sync`.

This investigation is deferred by the owner’s preference for practical agent
speed. It is not the next launch task. If resumed later, first verify no large model is running, available
memory is at least110GiB, all execution bindings still match, and the normal
service-control path is accessible. Use the already prepared launcher through
the existing inference lock, identity guard, cgroup and memory watchdog:

```bash
python3 /home/bmarti44/.cache/glm53-flash/server-bringup-019-context-sync/launch-frozen.py /home/bmarti44/.cache/glm53-flash/server-bringup-019-context-sync
```

After health and a short authenticated response, run the unchanged context
client against the prepared inputs:

```bash
python3 scripts/48_probe_glm53_context.py run \
  --output results/glm53-flash-gates/context-direct-004-prepared \
  --server /home/bmarti44/.cache/glm53-flash/server-bringup-019-context-sync
```

Current execution is blocked by the session's managed sandbox: the runtime
directories are read-only and the service-bus query is denied. Owner approval
for the work is present. Session018 was already stopped cleanly before the
permissions changed. Do not bypass containment to launch the model.
