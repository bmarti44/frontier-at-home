import ast,hashlib,json,os,subprocess,sys
from pathlib import Path
os.environ['CUDA_VISIBLE_DEVICES']=''
source=Path('/tmp/glm53-bf16-tiny-parity004.py'); root=Path(__file__).parent
import torch
torch.set_num_threads(2)
ns={'torch':torch,'hashlib':hashlib,'rec':lambda **kw:None}
module=ast.parse(source.read_text())
exec(compile(ast.Module(body=[x for x in module.body if isinstance(x,ast.FunctionDef) and x.name in ('same','digest')],type_ignores=[]),str(source),'exec',optimize=0),ns)
results=[]
def reject(name,a,b):
 try:ns['same'](a,b,name)
 except AssertionError:results.append({'name':name,'rejected':True});return
 raise AssertionError('Accepted '+name)
a=torch.tensor([1.,2.],dtype=torch.bfloat16)
ns['same'](a,a.clone(),'control')
reject('finite_mismatch',a,torch.tensor([1.,3.],dtype=a.dtype))
reject('matching_nan',torch.full_like(a,float('nan')),torch.full_like(a,float('nan')))
reject('matching_inf',torch.full_like(a,float('inf')),torch.full_like(a,float('inf')))
reject('missing_tensor',a,None)
reject('wrong_shape',a,a.unsqueeze(0))
reject('wrong_dtype',a,a.float())
text=source.read_text(); old="  information,offload=convert_and_load_state_dict_in_model(partial,raw,cfg)"
assert text.count(old)==1
new="  if prefixes == ['model.language_model.layers.2.']: raw={}\n"+old
mutant=root/'missing-stage.py';mutant.write_text(text.replace(old,new))
r=subprocess.run([sys.executable,'-I','-B',str(mutant),str(root/'missing-stage-result')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
(root/'missing-stage.stdout').write_bytes(r.stdout);(root/'missing-stage.stderr').write_bytes(r.stderr)
summary=json.loads((root/'missing-stage-result/summary.json').read_text())
assert r.returncode!=0 and summary['verdict']=='FAIL' and 'AssertionError' in summary['error'],summary
results.append({'name':'empty_layer2_checkpoint_selection','rejected':True,'exit_code':r.returncode,'error':summary['error']})
(root/'results.json').write_text(json.dumps({'verdict':'PASS','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'controls':results},indent=2)+'\n')
print((root/'results.json').read_text())
