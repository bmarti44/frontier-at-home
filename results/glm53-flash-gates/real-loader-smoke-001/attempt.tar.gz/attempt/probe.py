import hashlib, json, os, sys, time
from pathlib import Path
import torch
from safetensors import safe_open
from vllm.model_executor.model_loader.weight_utils import instanttensor_weights_iterator
root=Path(__file__).parent
source=Path(sys.argv[1])
expected=json.loads((root/'manifest.json').read_text())
with source.open('rb') as stream:
    if hashlib.file_digest(stream,'sha256').hexdigest()!=expected['source']['sha256']:
        raise ValueError('source hash mismatch')
staging=torch.empty(8<<20,dtype=torch.uint8,pin_memory=True)
assert staging.is_pinned()
seen=set();checked=0;start=time.time()
with safe_open(source,framework='pt',device='cpu') as reference,(root/'raw.jsonl').open('w') as raw:
    for name,tensor in instanttensor_weights_iterator([str(source)],False):
        assert name not in seen and tensor.is_cuda and tensor.is_contiguous()
        seen.add(name)
        wanted=reference.get_tensor(name)
        assert tensor.shape==wanted.shape and tensor.dtype==wanted.dtype
        wanted_bytes=wanted.reshape(-1).view(torch.uint8)
        actual_bytes=tensor.reshape(-1).view(torch.uint8)
        actual=hashlib.sha256()
        for offset in range(0,actual_bytes.numel(),staging.numel()):
            count=min(staging.numel(),actual_bytes.numel()-offset)
            staging[:count].copy_(actual_bytes[offset:offset+count],non_blocking=True)
            torch.cuda.synchronize()
            actual.update(memoryview(staging[:count].numpy()))
        wanted_hash=hashlib.sha256(memoryview(wanted_bytes.numpy())).hexdigest()
        assert actual.hexdigest()==wanted_hash
        checked+=actual_bytes.numel()
        raw.write(json.dumps({'time_unix':time.time(),'tensor':name,'bytes':actual_bytes.numel(),'sha256':wanted_hash})+'\n');raw.flush()
        del wanted,wanted_bytes,actual_bytes,tensor
    assert seen==set(reference.keys())
summary={'verdict':'PASS','scope':'one real shard loader correctness only','model_loaded':False,'tensors':len(seen),'bytes_checked':checked,'start_unix':start,'end_unix':time.time(),'cuda_peak_allocated':torch.cuda.max_memory_allocated()}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
