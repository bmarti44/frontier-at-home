import json,sys
from pathlib import Path
sys.path.insert(0,'/home/bmarti44/spark-deepseek-v4-flash/scripts/lib')
from glm53_probe_capture import inference_lock,capture_wrapper
root=Path(__file__).parent
m=json.loads((root/'manifest.json').read_text())
control={'HOME':'/home/bmarti44','USER':'bmarti44','LOGNAME':'bmarti44','LANG':'C.UTF-8','PATH':'/usr/bin:/bin','XDG_RUNTIME_DIR':'/run/user/1000','DBUS_SESSION_BUS_ADDRESS':'unix:path=/run/user/1000/bus'}
with inference_lock() as lock:
 env={**control,**lock,'GLM_SAFE_RUN_AS_CURRENT_USER':'1','GLM_SAFE_MIN_START_GIB':'110','GLM_SAFE_KILL_FLOOR_GIB':'40','GLM_SAFE_TIMEOUT_S':'600','GLM_SAFE_DONE_DIGESTS':'1'}
 cmd=['/usr/bin/env','-i',*(k+'='+v for k,v in sorted(m['environment'].items())),m['python']['path'],'-I','-B',str(root/'guard.py'),'--output',str(root/'identity'),'--',str(root/'probe.py'),m['source']['path']]
 print(capture_wrapper(root,Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm52-gates/harness/glm_cgroup_run.sh'),'glm53-loader-smoke-001',cmd,env,600),flush=True)
