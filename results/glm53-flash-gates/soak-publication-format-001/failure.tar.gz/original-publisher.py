"""Publish retained failed durability evidence without changing its scorer."""
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
import sys
import tarfile
from pathlib import Path

R = Path('/home/bmarti44/spark-deepseek-v4-flash')
B = Path.home() / '.cache/glm53-flash'
C = B / 'soak-native-003'
P = B / 'soak-native-003-observations'
S = B / 'server-20260910-035500'
F = B / 'soak-freeze-004'
W = Path.home() / '.local/state/glm52-crashlog/20260910-035550-glm53-dev-2559107'
O = R / 'results/glm53-flash-gates/soak-native-003'

def read(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def used_swap(meminfo):
    values = {key: int(value.split()[0]) for key, value in
              (line.split(':', 1) for line in meminfo.splitlines())}
    return values['SwapTotal'] - values['SwapFree']

spec = importlib.util.spec_from_file_location('glm_soak_publication', R / 'results/glm53-flash-gates/soak-native-001/run.py')
runner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = runner
spec.loader.exec_module(runner)
runner.verify(C)
for row in read(F / 'manifest.json')['files']:
    path = Path(row['path'])
    assert path.stat().st_size == row['size_bytes'] and sha(path) == row['sha256'], path

original = read(C / 'summary.json')
assert original['verdict'] == 'FAIL' and 'first window worker coverage' in original['error']
journal = [read_row for line in (C / 'raw.jsonl').read_text().splitlines()
           if (read_row := runner.decode(line))]
assert journal[0]['kind'] == 'start' and journal[-1]['kind'] == 'end'
start, deadline = journal[0]['start_ns'], journal[0]['deadline_ns']
assert deadline == start + 1800 * 10**9
requests = []
for row in journal[1:-1]:
    assert row['kind'] == 'request' and row['verdict'] == 'PASS'
    result = runner.score_request(C / row['raw_path'], read(C / f"{row['worker']}-input-token-ids.json"),
                                  read(C / f"{row['worker']}-fixture.json"))
    assert all(row[key] == value for key, value in result.items())
    requests.append({**result, 'worker': row['worker'], 'index': row['index']})
first_counts = [sum(row['worker'] == worker and row['start_ns'] < start + 300 * 10**9
                    for row in requests) for worker in range(4)]
last_counts = [sum(row['worker'] == worker and row['start_ns'] >= deadline - 300 * 10**9
                   for row in requests) for worker in range(4)]
assert first_counts == [3, 3, 4, 3]
monitor = read(C / 'monitor.json')
watchdog = []
for line in (W / 'samples.log').read_text().splitlines():
    timestamp, *fields = line.split()
    values = dict(field.split('=', 1) for field in fields)
    watchdog.append({'time_unix': datetime.datetime.fromisoformat(timestamp.replace(',', '.')).timestamp(),
                     'available_gib': int(values['mem_avail_kb']) / 1048576,
                     'cgroup_swap_bytes': int(values['cgroup_swap_current_bytes'])})

before, middle, prior, after = [read(P / name) for name in
                               ['before.json', 'mid-run.json', 'pre-stop.json', 'after.json']]
guard = read(S / 'identity/summary.json')
host_swap = [used_swap(observation['meminfo']) for observation in [before, middle, prior, after]]
checks = {
    'fixed_durability_client_gate': False,
    'all_completed_requests_independently_rescored_correct': bool(requests),
    'full_1800_second_admission_and_bounded_drain': deadline <= journal[-1]['drained_ns'] <= start + 2400 * 10**9
        and not journal[-1]['stopped_on_failure'],
    'whole_host_no_new_swap': max(host_swap) <= host_swap[0],
    'watchdog_floor_at_least_18_gib': min(row['available_gib'] for row in watchdog) >= 18,
    'all_watchdog_cgroup_swap_samples_zero': all(row['cgroup_swap_bytes'] == 0 for row in watchdog),
    'cgroup_swap_peak_zero_before_stop': int(prior['cgroup_files']['memory.swap.peak']) == 0,
    'identity_guard_and_clean_descendants': guard['verdict'] == 'PASS' and guard['probe_exit_code'] == 0
        and guard['raw_sha256'] == sha(S / 'identity/raw.jsonl') and not guard['live_process_group_after'],
    'operator_stop_and_wrapper_exit_zero': read(P / 'stop-command.json')['exit_code'] == read(S / 'exit.json')['exit_code'] == 0,
    'processes_gone': not after['prior_pids_still_present'] and not (after['cgroup_files']['cgroup.procs'] or '').strip(),
    'profile_stopped': json.loads(after['profile_status']['stdout'])['state'] == 'stopped',
    'memory_recovery_above_110_gib': read(P / 'memory-recovery.json')['pass'],
    'default_proxy_and_guards_unchanged': all(after['default_proxy_guard_checks'].values()),
    'kernel_journal_clear': after['kernel']['exit_code'] == 0 and after['kernel']['stdout'].strip() == '-- No entries --',
    'post_runtime_model_verification': read(P / 'post-artifact-verification.json')['pass_check'],
    'frozen_source_bindings_unchanged': True,
}
cache_observations = {name: read(P / name) for name in
    ['cache-at-launch.json', 'cache-after-short.json', 'cache-before-stop.json', 'cache-after-stop.json']}
checks['prepared_compiled_inputs_unchanged'] = all(not observation['changed'] and not observation['missing']
                                                for observation in cache_observations.values())
summary = {
    'scope': 'Full 1800-second native four-client durability attempt on the experimental aggregate-1M profile; short-prompt workload, not a context or production speed result',
    'verdict': 'FAIL',
    'formula': 'Unchanged soak-native-001/PROTOCOL.md and run.py client gate conjoined with native lifecycle, frozen bindings and host checks. Every required condition must pass. No statistical performance or fidelity verdict.',
    'client_summary': original,
    'failures': ['First 300-second admissions per worker below five: ' + str(first_counts),
                 'Final 300-second admissions per worker below five: ' + str(last_counts),
                 'Whole-host swap use increased after preflight; GLM cgroup swap remained zero. Attribution is unknown.'],
    'checks': checks,
    'source_revision': read(F / 'manifest.json')['source_revision'],
    'request_observations': {'completed': len(requests),
        'completed_per_worker': [sum(row['worker'] == worker for row in requests) for worker in range(4)],
        'input_tokens_per_request': 4224, 'first300s_admissions_per_worker': first_counts,
        'last300s_admissions_per_worker': last_counts,
        'admission_seconds': 1800, 'drain_completed_after_seconds': (journal[-1]['drained_ns'] - start) / 1e9,
        'observations_ended_after_seconds': (journal[-1]['ended_ns'] - start) / 1e9,
        'all_final_answers_and_negative_controls_correct': True},
    'host': {'watchdog_samples': len(watchdog),
        'minimum_available_gib': min(row['available_gib'] for row in watchdog),
        'maximum_cgroup_swap_bytes': max(row['cgroup_swap_bytes'] for row in watchdog),
        'host_used_swap_kib_before_midrun_prestop_after': host_swap,
        'maximum_observed_increase_in_host_used_swap_kib': max(host_swap) - host_swap[0],
        'identity_samples': guard['identity_samples'],
        'client_memory_samples': len(monitor['memory']), 'health_probes': len(monitor['health']),
        'all_health_statuses_200': all(row['status'] == 200 for row in monitor['health'])},
    'startup': {'ready': True, 'retrieval_smoke': read(C / 'smoke/summary.json')['verdict'],
        'observed_effect': 'Verified-file startup advice reclaimed cached model pages before CUDA initialization; this launch loaded and served without recorded CUDA OOM. The two startup flags were jointly enabled; no isolated causal or performance claim.'},
    'full_model_qualification': 'NO_RESULT: fixed durability and no-new-host-swap gates failed; native 100-case paired fidelity and production switching remain pending',
    'qualified_production_performance': None,
}
O.mkdir(exist_ok=False)
save(O / 'summary.json', summary)
raw = b''.join((json.dumps({'kind': 'retained_observation', 'source': str(P / name),
                          'sha256': sha(P / name), 'observation': read(P / name)}, allow_nan=False) + '\n').encode()
               for name in ['before.json', 'mid-run.json', 'pre-stop.json', 'stop-command.json',
                            'after.json', 'memory-recovery.json', 'post-artifact-verification.json'])
compressed = gzip.compress(raw, mtime=0)
assert gzip.decompress(compressed) == raw
(O / 'raw.jsonl.gz').write_bytes(compressed)
secret = (S / 'api-key').read_bytes().strip()
assert len(secret) > 20
files, entries = [], {}
for prefix, root in [('freeze', F), ('client', C), ('observations', P), ('server', S), ('watchdog', W)]:
    for path in sorted(root.rglob('*')):
        if path.is_file() and path != S / 'api-key':
            entries[prefix + '/' + str(path.relative_to(root))] = path
entries['publication/publish.py'] = Path(__file__)
for row in read(F / 'manifest.json')['files']:
    path = Path(row['path'])
    if path.is_relative_to(R):
        entries['source/' + str(path.relative_to(R))] = path
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz', compresslevel=6) as archive:
    for name, path in sorted(entries.items()):
        data = path.read_bytes()
        assert secret not in data, name
        files.append({'path': name, 'size_bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        archive.add(path, arcname=name, recursive=False)
data = buffer.getvalue()
parts = []
for index, offset in enumerate(range(0, len(data), 32 * 1024**2)):
    chunk = data[offset:offset + 32 * 1024**2]
    path = O / f'attempt.tar.gz.part-{index:03d}'
    path.write_bytes(chunk)
    parts.append({'path': path.name, 'size_bytes': len(chunk), 'sha256': hashlib.sha256(chunk).hexdigest()})
expected = {row['path']: row for row in files}
seen = set()
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        blob = archive.extractfile(member).read()
        assert member.size == expected[member.name]['size_bytes']
        assert hashlib.sha256(blob).hexdigest() == expected[member.name]['sha256']
assert seen == set(expected)
save(O / 'manifest.json', {'scope': summary['scope'], 'source_revision': summary['source_revision'],
    'archive': {'size_bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()},
    'parts': parts, 'files': files, 'summary': {'sha256': sha(O / 'summary.json')},
    'raw': {'path': 'raw.jsonl.gz', 'sha256': sha(O / 'raw.jsonl.gz'),
            'uncompressed_sha256': hashlib.sha256(raw).hexdigest(), 'uncompressed_size_bytes': len(raw)},
    'verification': 'Every archive member and compressed raw stream round-trip verified; API key excluded and bytes scanned. Frozen source files and closed runtime/model inventories verified after stop. Native request bytes rescored by unchanged request scorer; original client FAIL retained.'})
print(json.dumps({'verdict': 'FAIL', 'requests': len(requests), 'checks': checks,
                  'archive_members': len(files), 'archive_bytes': len(data)}), flush=True)
