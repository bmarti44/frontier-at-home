"""Retain actual named-profile startup observations; no serving changes."""
import hashlib,json,subprocess,sys,time,urllib.error,urllib.request
from pathlib import Path
repo=Path('/home/bmarti44/spark-deepseek-v4-flash');sys.path.insert(0,str(repo/'scripts/lib'));import glm53_profile as api
freeze,server,out=map(Path,sys.argv[1:]);name='glm-5.3-flash/cuda-spark-128g-1m-experimental'
def read(p):return json.loads(p.read_text())
def save(name,d): (out/name).write_text(json.dumps(d,indent=2)+'\n')
def cmd(a):
 r=subprocess.run(a,capture_output=True,text=True,timeout=35);return {'command':a,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
record=read(api.lifecycle_path(name));save('running-record.json',record)
assert record['ready'] and record['phase']=='running' and record['output']==str(server)
status=cmd([str(repo/'scripts/93_profile_serve.sh'),'--profile',name,'status']);save('running-status-command.json',status);assert status['exit_code']==0 and json.loads(status['stdout'])['state']=='running'
snapshot=read(server/'profile-snapshot.json');planned=read(freeze/'profile-snapshot-template.json')
assert snapshot==json.loads(json.dumps(planned).replace(str(freeze/'run-root-placeholder'),str(server)))
launch=read(server/'launch.json');assert launch['arguments']==snapshot['argv'][4:] and launch['environment']==snapshot['env']
props=cmd(['systemctl','--user','show',record['unit'],'--property=RuntimeMaxUSec,MainPID,OOMPolicy,ControlGroup,MemoryHigh,MemoryMax,MemorySwapMax,KillMode,ActiveState,InvocationID']);save('running-properties-command.json',props)
v=dict(line.split('=',1) for line in props['stdout'].splitlines());assert props['exit_code']==0
for k,want in {'RuntimeMaxUSec':'2h 31min','OOMPolicy':'kill','MemoryHigh':str(92*1024**3),'MemoryMax':str(94*1024**3),'MemorySwapMax':'0','KillMode':'control-group','ActiveState':'active','InvocationID':record['invocation_id'],'ControlGroup':record['control_group']}.items():assert v[k]==want,(k,v[k],want)
cg=Path('/sys/fs/cgroup')/record['control_group'].lstrip('/');pids=[int(x) for x in (cg/'cgroup.procs').read_text().split()]
identities=[]
for pid in pids:
 try:identities.append(api.process_identity(pid))
 except FileNotFoundError:pass
save('running-identities.json',{'time_unix':time.time(),'identities':identities,'cgroup_swap':(cg/'memory.swap.current').read_text(),'memory_events':(cg/'memory.events').read_text()})
import importlib.util
spec=importlib.util.spec_from_file_location('actual_worker_libc',repo/'results/glm53-flash-gates/startup-heap-trim-001/bind_libc.py');libc_api=importlib.util.module_from_spec(spec);spec.loader.exec_module(libc_api)
provider=read(freeze/'libc-provider.json')['provider']
workers=[identity for identity in identities if identity['command']==['VLLM::EngineCore']]
assert len(workers)==1,'expected one identity-verified GLM engine core'
mappings=[]
for identity in workers:
 assert api.process_identity(identity['pid'])==identity
 mappings.append(libc_api.verify_mapping(identity['pid'],provider))
 assert api.process_identity(identity['pid'])==identity
save('native-libc-provider-check.json',{'time_unix':time.time(),'pass':True,'workers':workers,'mappings':mappings})

save('running-processes.json',cmd(['ps','-p',','.join(str(x) for x in pids),'-o','pid,ppid,stat,args']))
save('running-listeners.json',cmd(['ss','-ltnpe','( sport = :8010 or sport = :8015 )']))
key=(server/'api-key').read_text().strip()
def http(path,auth,body=None):
 headers={'Content-Type':'application/json'}
 if auth:headers['Authorization']='Bearer '+key
 start=time.time();request=urllib.request.Request('http://127.0.0.1:8015'+path,data=None if body is None else json.dumps(body).encode(),headers=headers)
 try:
  with urllib.request.urlopen(request,timeout=120) as response:code=response.status;text=response.read().decode()
 except urllib.error.HTTPError as error:code=error.code;text=error.read().decode()
 row={'start_unix':start,'end_unix':time.time(),'path':path,'authenticated':auth,'request_body':body,'status':code,'response_body':text}
 with (out/'http-raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 return row
health=http('/health',False);reject=http('/v1/models',False);models=http('/v1/models',True)
body={'model':'glm-5.3-flash','messages':[{'role':'user','content':'Reply with exactly READY'}],'temperature':0,'max_tokens':64,'chat_template_kwargs':{'enable_thinking':False}}
ready=http('/v1/chat/completions',True,body)
assert health['status']==200 and reject['status']==401 and models['status']==ready['status']==200
assert any(r['id']=='glm-5.3-flash' and r['max_model_len']==262144 for r in json.loads(models['response_body'])['data'])
c=json.loads(ready['response_body'])['choices'][0];assert c['finish_reason']=='stop' and c['message']['content']=='READY',c
save('native-launch-checks.json',{'time_unix':time.time(),'exact_snapshot_arguments_environment':True,'containment_exact':True,'authentication_health_and_completed_ready':True})
before=read(out/'before.json');kernel=cmd(['journalctl','-k','--since','@'+str(int(before['time_unix'])),'--no-pager','-o','short-iso-precise']);save('kernel-before-requests.json',kernel);assert kernel['exit_code']==0
import re
assert not re.search(r'NVRM: Xid|NV_ERR_NO_MEMORY|Out of memory|oom-kill|Killed process',kernel['stdout'],re.I)
print('PASS: actual native profile configuration/containment, authentication, health and completed READY',flush=True)
