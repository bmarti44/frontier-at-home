"""Capture terminal host facts for an existing native durability attempt."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/bmarti44/spark-deepseek-v4-flash')
sys.path.insert(0, str(ROOT / 'scripts/lib'))
import glm53_profile as api

phase, observation_directory = sys.argv[1:]
out = Path(observation_directory)
record = json.loads((out / 'running-record.json').read_text())
before = json.loads((out / 'before.json').read_text())
cgroup = Path('/sys/fs/cgroup') / record['control_group'].lstrip('/')

def command(argv):
    started = time.time()
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, timeout=45)
    return {'command': argv, 'start_unix': started, 'end_unix': time.time(),
            'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

def optional(path):
    return path.read_text() if path.exists() else None

facts = {'time_unix': time.time(), 'monotonic_ns': time.monotonic_ns(),
         'meminfo': Path('/proc/meminfo').read_text(),
         'vmstat': Path('/proc/vmstat').read_text(),
         'cgroup_path': str(cgroup), 'cgroup_exists': cgroup.exists(),
         'cgroup_files': {name: optional(cgroup / name) for name in
                          ['cgroup.procs', 'memory.current', 'memory.peak',
                           'memory.events', 'memory.events.local',
                           'memory.swap.current', 'memory.swap.peak', 'memory.swap.events',
                           'memory.high', 'memory.max', 'memory.swap.max']}}
identities = []
for pid in (facts['cgroup_files']['cgroup.procs'] or '').split():
    try:
        identities.append(api.process_identity(int(pid)))
    except FileNotFoundError:
        identities.append({'pid': int(pid), 'exited_during_observation': True})
facts['identities'] = identities
facts['properties'] = command(['systemctl', '--user', 'show', record['unit'],
    '--property=RuntimeMaxUSec,MainPID,OOMPolicy,ControlGroup,MemoryHigh,MemoryMax,MemorySwapMax,KillMode,ActiveState,InvocationID,Result'])
for key in ['switch_status', 'proxy', 'listeners', 'guards', 'profile_status']:
    facts[key] = command(before[key]['command'])
state_path = Path(before['production_state']['path'])
facts['production_state'] = {'path': str(state_path),
                            'sha256': hashlib.sha256(state_path.read_bytes()).hexdigest()}
facts['kernel'] = command(['journalctl', '-k', '--since', '@' + str(int(before['time_unix'])),
                          '--no-pager', '-o', 'short-iso-precise'])
if phase == 'after':
    prior = json.loads((out / 'pre-stop.json').read_text())
    facts['prior_pids_still_present'] = [identity['pid'] for identity in prior['identities']
        if Path('/proc').joinpath(str(identity['pid'])).exists()]
    facts['default_proxy_guard_checks'] = {
        'production_state_unchanged': facts['production_state'] == before['production_state'],
        **{key + '_unchanged': facts[key]['exit_code'] == before[key]['exit_code'] == 0
           and facts[key]['stdout'] == before[key]['stdout']
           for key in ['switch_status', 'proxy', 'listeners', 'guards']}}
destination = out / (phase + '.json')
with destination.open('x') as stream:
    json.dump(facts, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'path': str(destination), 'phase': phase,
                  'cgroup_process_count': len(identities),
                  'mem_available_kib': int(dict(line.split(':', 1) for line in
                       facts['meminfo'].splitlines())['MemAvailable'].split()[0])}))
