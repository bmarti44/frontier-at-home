"""Read-only cache inventory, using the existing frozen relocation rule."""
import hashlib,json,sys,time
from pathlib import Path
freeze,server,output=map(Path,sys.argv[1:])
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
state=server/'state';expected=json.loads((freeze/'prepared-cache-inventory.json').read_text());observed=[]
for p in sorted(state.rglob('*')):
 if not p.is_file():continue
 row={'path':str(p.relative_to(state)),'size_bytes':p.stat().st_size,'sha256':sha(p)}
 if p.name.startswith('__grp__') and p.suffix=='.json':
  d=json.loads(p.read_text());children={}
  for k,v in d['child_paths'].items():
   q=Path(v)
   if not q.is_relative_to(state) or not q.is_file():raise ValueError('unclosed cache child')
   children[k]='{state_root}/'+str(q.relative_to(state))
  row['relocated_group']={'sha256':hashlib.sha256(json.dumps({'child_paths':children},sort_keys=True,separators=(',',':')).encode()).hexdigest()}
 observed.append(row)
actual={r['path']:r for r in observed};baseline={r['path']:r for r in expected['files']};missing=[];changed=[]
for name,row in baseline.items():
 if name not in actual:missing.append(name);continue
 a=actual[name]
 mismatch=(a.get('relocated_group')!=row['relocated_group']) if 'relocated_group' in row else (a['sha256']!=row['sha256'] or a['size_bytes']!=row['size_bytes'])
 if mismatch:changed.append(name)
added=[r for n,r in actual.items() if n not in baseline]
allowed={'.config/vllm/usage_stats.json','.humming/tmp/lock/launcher.lock'}
d={'time_unix':time.time(),'normalization':expected['normalization'],'baseline_files':len(baseline),'files':observed,'changed':changed,'missing':missing,'added':added,'compiled_inputs_unchanged':not changed and not missing and all(r['path'] in allowed for r in added)}
output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k] for k in ['baseline_files','changed','missing','compiled_inputs_unchanged']}),flush=True)
assert d['compiled_inputs_unchanged']
