from pathlib import Path
import hashlib,json,subprocess,time
base=Path.home()/'.cache/glm53-flash';out=base/'context-direct-008-observations';previous=json.loads((base/'soak-native-005-observations/before.json').read_text())
def command(argv):
 start=time.time();r=subprocess.run(argv,capture_output=True,text=True,timeout=45)
 return {'command':argv,'start_unix':start,'end_unix':time.time(),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
facts={'time_unix':time.time(),'monotonic_ns':time.monotonic_ns(),'meminfo':Path('/proc/meminfo').read_text(),'vmstat':Path('/proc/vmstat').read_text()}
state=Path(previous['production_state']['path']);facts['production_state']={'path':str(state),'sha256':hashlib.sha256(state.read_bytes()).hexdigest()}
for key in ['switch_status','proxy','listeners','guards','profile_status','processes']:
 facts[key]=command(previous[key]['command'])
assert facts['production_state']==previous['production_state']
assert all(facts[k]['exit_code']==0 for k in ['switch_status','proxy','listeners','guards','profile_status'])
assert json.loads(facts['profile_status']['stdout'])['state']=='stopped'
assert ':8015' not in facts['listeners']['stdout']
mem=dict(line.split(':',1) for line in facts['meminfo'].splitlines());assert int(mem['MemAvailable'].split()[0])>=110*1024**2
with (out/'before.json').open('x') as f:json.dump(facts,f,indent=2);f.write('\n')
print(json.dumps({'captured_before':facts['time_unix'],'memory_gib':int(mem['MemAvailable'].split()[0])/1024**2}))
