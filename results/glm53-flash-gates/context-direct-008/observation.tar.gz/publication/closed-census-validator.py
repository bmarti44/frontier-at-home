"""Preserve a startup host-gate failure; no timed workload was admitted."""
import datetime,gzip,hashlib,importlib.util,io,json,math,re,sys,tarfile
from pathlib import Path
R=Path('/home/bmarti44/spark-deepseek-v4-flash');B=Path.home()/'.cache/glm53-flash'
C=B/'soak-native-009';P=B/'soak-native-009-observations';S=B/'server-20260910-075433';F=B/'soak-freeze-010'
W=Path.home()/'.local/state/glm52-crashlog/20260910-075523-glm53-dev-2824801';O=R/'results/glm53-flash-gates/soak-native-009'
def reject_constant(value):raise ValueError('Nonfinite JSON constant: '+value)
def read(path):return json.loads(path.read_text(),parse_constant=reject_constant)
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def save(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def validate_census(rows):
 assert rows[0]['kind']=='start' and rows[-1]['kind']=='end'
 assert all(row['kind']=='census' for row in rows[1:-1])
 assert [row['index'] for row in rows[1:-1]]==list(range(900))
 assert rows[-1]['completed_censuses']==900
 assert all(a['observed_ns']<b['observed_ns'] for a,b in zip(rows,rows[1:]))
 counters=[rows[0]['counters']]+[x for r in rows[1:-1] for x in [r['before'],r['after']]]+[rows[-1]['counters']]
 for x in counters:
  assert all(type(x[k])is int and x[k]>=0 for k in ['observed_ns','pswpin','pswpout','MemAvailable_kib','SwapTotal_kib','SwapFree_kib','SwapCached_kib'])
  assert type(x['time_unix']) in (int,float) and math.isfinite(x['time_unix'])
 for a,b in zip(counters,counters[1:]):
  assert a['observed_ns']<=b['observed_ns'] and a['pswpin']<=b['pswpin'] and a['pswpout']<=b['pswpout']
 return counters

def main():
 spec=importlib.util.spec_from_file_location('replay_publication',R/'results/glm53-flash-gates/soak-scheduler-002/candidate.py');api=importlib.util.module_from_spec(spec);sys.modules[spec.name]=api;spec.loader.exec_module(api);api.runner.verify(C)
 frozen=read(F/'manifest.json')
 for row in frozen['files']:
  path=Path(row['path']);assert path.stat().st_size==row['size_bytes'] and sha(path)==row['sha256'],path
 assert not any((C/name).exists() for name in ['first-window','raw.jsonl','first-window-admission-binding.json'])
 smoke=api.runner.score_request(C/'smoke/raw.jsonl',read(C/'0-input-token-ids.json'),read(C/'0-fixture.json'))
 smoke.update(verdict='PASS',scope='startup correctness only',manifest_sha256=api.runner.verify(C))
 assert smoke==read(C/'smoke/summary.json')
 before,prior,after=[read(P/name) for name in ['before.json','pre-stop.json','after.json']]
 guard=read(S/'identity/summary.json');cache=read(P/'cache-after-stop.json');samples=[]
 for line in (W/'samples.log').read_text().splitlines():
  stamp,*fields=line.split();values=dict(x.split('=',1) for x in fields);samples.append({'time_unix':datetime.datetime.fromisoformat(stamp.replace(',','.')).timestamp(),'available_gib':int(values['mem_avail_kb'])/1048576,'cgroup_swap_bytes':int(values['cgroup_swap_current_bytes'])})
 vm=[dict((k,int(v)) for k,v in (line.split() for line in x['vmstat'].splitlines())) for x in [before,prior,after]]
 used=[]
 for x in [before,prior,after]:
  m=dict((k,int(v.split()[0])) for k,v in (line.split(':',1) for line in x['meminfo'].splitlines()));used.append(m['SwapTotal']-m['SwapFree'])
 rows=[json.loads(x,parse_constant=reject_constant) for x in (P/'swap-census/raw.jsonl').read_text().splitlines()];counters=validate_census(rows)
 phases=[read(p) for p in sorted(P.glob('phase-*.json'))]
 assert len(phases)==8 and {p['phase'] for p in phases}=={'before_freeze','after-freeze','after-randomness','after-fixture-preparation','before_profile_start','after_ready','after_smoke','after_stop'}
 assert all(rows[0]['counters']['time_unix']<=p['counters']['time_unix']<=rows[-1]['counters']['time_unix'] for p in phases)
 assert rows[-1]['counters']['time_unix']>read(P/'post-artifact-verification.json')['end_unix']
 changes=[]
 census=rows[1:-1]
 for a,b in zip(census,census[1:]):
  delta={k:b['after'][k]-a['after'][k] for k in ['pswpin','pswpout']}
  if not any(delta.values()):continue
  old={(p['pid'],p.get('start_ticks')):p for p in a['processes'] if 'read_error'not in p};correlations=[]
  for p in b['processes']:
   q=old.get((p['pid'],p.get('start_ticks')))
   if q is None or 'read_error'in p:continue
   diffs={k:p[k]-q[k] for k in ['vm_swap_kib','major_faults'] if p.get(k)is not None and q.get(k)is not None and p[k]!=q[k]}
   if diffs:correlations.append({'pid':p['pid'],'name':p['name'],'start_ticks':p['start_ticks'],'cgroup':p['cgroup'],'deltas':diffs})
  changes.append({'interval_start_unix':a['after']['time_unix'],'interval_end_unix':b['after']['time_unix'],'deltas':delta,'process_correlations_not_causal_attribution':correlations})
 provider=read(F/'libc-provider.json')['provider'];mapped=read(P/'native-libc-provider-check.json');heap=read(P/'heap-trim-observation.json')
 assert mapped['pass'] is True and len(mapped['workers'])==len(mapped['mappings'])==1
 worker=mapped['workers'][0];mapping=mapped['mappings'][0]
 assert worker['command']==['VLLM::EngineCore'] and mapping['pid']==worker['pid'] and mapping['provider']==provider and mapping['maps']
 import os
 for line in mapping['maps']:
  fields=line.split(maxsplit=5);assert fields[5]==provider['path'] and int(fields[4])==provider['inode'] and os.makedev(*(int(x,16) for x in fields[3].split(':')))==provider['device']
 assert sha(Path(provider['path']))==provider['sha256']
 assert [e['phase'] for e in heap['events']]==['before-profile','after-profile']
 assert all(e['pid']==worker['pid'] for e in heap['events'])
 for line,event in zip(heap['original_lines'],heap['events']):
  assert line in (W/'cmd.log').read_text().splitlines() and json.loads(line[line.index('{'):])==event
 assert heap['reported_anonymous_release_kib']==[e['before']['anonymous_rss_kib']-e['after']['anonymous_rss_kib'] for e in heap['events']]
 native=read(P/'native-launch-checks.json');assert set(native)=={'time_unix','exact_snapshot_arguments_environment','containment_exact','authentication_health_and_completed_ready'}
 events=dict(line.split() for line in prior['cgroup_files']['memory.events'].splitlines());assert set(events)=={'low','high','max','oom','oom_kill','oom_group_kill'}
 checks={'actual_native_libc_provider_mapping_and_heap_observations':True,'short_correctness_rescored_from_raw':True,'actual_native_configuration_authentication_ready':all(native[k] is True for k in ['exact_snapshot_arguments_environment','containment_exact','authentication_health_and_completed_ready']),
 'whole_host_no_new_swap':max(used)<=used[0],
 'whole_host_no_swap_io':all(x[k]==vm[0][k] for x in vm for k in ['pswpin','pswpout']),
 'watchdog_floor_at_least_18_gib':bool(samples) and min(x['available_gib'] for x in samples)>=18,
 'cgroup_swap_samples_and_peak_zero':all(x['cgroup_swap_bytes']==0 for x in samples) and int(prior['cgroup_files']['memory.swap.peak'])==0,
 'cgroup_no_limit_events':all(int(line.split()[1])==0 for line in prior['cgroup_files']['memory.events'].splitlines()),
 'guard_identity_and_clean_descendants':guard['verdict']=='PASS' and guard['probe_exit_code']==0 and not guard['live_process_group_after'] and guard['raw_sha256']==sha(S/'identity/raw.jsonl'),
 'operator_stop_and_wrapper_exit_zero':read(P/'stop-command.json')['exit_code']==read(S/'exit.json')['exit_code']==0,
 'processes_gone':not after['prior_pids_still_present'] and not (after['cgroup_files']['cgroup.procs']or'').strip(),
 'profile_stopped':json.loads(after['profile_status']['stdout'])['state']=='stopped',
 'memory_recovery_above_110_gib':read(P/'memory-recovery.json')['pass'],
 'default_proxy_guards_unchanged':all(after['default_proxy_guard_checks'].values()),
 'kernel_journal_clear':after['kernel']['exit_code']==0 and not re.search(r'NVRM: Xid|NV_ERR_NO_MEMORY|Out of memory|oom-kill|Killed process',after['kernel']['stdout'],re.I),
 'post_runtime_model_verification':read(P/'post-artifact-verification.json')['pass_check'],
 'frozen_compiled_inputs_unchanged':cache['compiled_inputs_unchanged'],
 'observer_complete_and_covers_preparation_startup_stop_verification':True,'frozen_source_bindings_unchanged':True}
 assert [k for k,v in checks.items() if not v]==['whole_host_no_swap_io']
 summary={'scope':'Second bounded CPU heap-trim experiment on 512/128; short correctness only, host gate failed before necessary window','source_revision':frozen['source_revision'],'verdict':'FAIL','formula':'Conjunction of frozen startup-heap-trim-001/PROTOCOL.md host, startup, cache and lifecycle checks; any new unattributed host swap I/O or used-swap growth rejects workload admission. Existing window/full-duration scorers are unchanged and were not run.','checks':checks,'qualification_input_tokens':0,'short_correctness_input_tokens':smoke['input_tokens'],'short_correctness':'PASS','timed_requests':0,'necessary_window':'NO_RESULT: host prerequisites failed before window admission','full_durability':'NO_RESULT: not admitted','qualified_production_performance':None,'host_swap':{'observation_order':['before','pre-stop','after'],'used_swap_kib':used,'pswpin':[x['pswpin'] for x in vm],'pswpout':[x['pswpout'] for x in vm]},'memory':{'watchdog_samples':len(samples),'minimum_available_gib':min(x['available_gib'] for x in samples),'identity_samples':guard['identity_samples']},'compiled_inputs':{'verdict':'PASS','baseline_files':cache['baseline_files'],'changed':cache['changed'],'missing':cache['missing'],'added':cache['added']},'external_observer':{'censuses':900,'counter_changes':changes,'attribution':'NO_RESULT: process VmSwap correlation is retained but does not establish causation or authorize a host-gate exemption','phase_observations':phases,'additional_unloaded_event_scope':'Events after after.json are retained diagnostic observations, separate from the startup-through-stop failure interval'}}
 summary['startup_reclamation_branch']={'verdict':'NO_RESULT','reason':'Both preregistered reclamation alternatives failed to reliably close the unchanged host gate; no third startup memory variant','reported_anonymous_release_kib':heap['reported_anonymous_release_kib'],'limitation':'Actual small RSS release is not causal host improvement or qualification'}
 O.mkdir(exist_ok=False);save(O/'summary.json',summary)
 raw=b''.join((json.dumps({'kind':'retained_observation','source':str(P/name),'sha256':sha(P/name),'observation':read(P/name)},allow_nan=False)+'\n').encode() for name in ['before.json','before-smoke.json','pre-stop.json','stop-command.json','after.json','memory-recovery.json','post-artifact-verification.json'])
 (O/'raw.jsonl.gz').write_bytes(gzip.compress(raw,mtime=0))
 secret=(S/'api-key').read_bytes().strip();assert len(secret)>20
 entries={}
 for prefix,root in [('freeze',F),('client',C),('observations',P),('server',S),('watchdog',W)]:
  for p in sorted(root.rglob('*')):
   if p.is_file() and p!=S/'api-key':entries[prefix+'/'+str(p.relative_to(root))]=p
 entries['publication/publish.py']=Path(__file__)
 for row in frozen['files']:
  p=Path(row['path'])
  if p.is_relative_to(R):entries['source/'+str(p.relative_to(R))]=p
 buf=io.BytesIO();files=[]
 with tarfile.open(fileobj=buf,mode='w:gz',compresslevel=6) as tf:
  for name,p in sorted(entries.items()):
   blob=p.read_bytes();assert secret not in blob,name;files.append({'path':name,'size_bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()});tf.add(p,arcname=name,recursive=False)
 blob=buf.getvalue();parts=[]
 for i,offset in enumerate(range(0,len(blob),32*1024**2)):
  data=blob[offset:offset+32*1024**2];p=O/f'attempt.tar.gz.part-{i:03d}';p.write_bytes(data);parts.append({'path':p.name,'size_bytes':len(data),'sha256':sha(p)})
 expected={x['path']:x for x in files};seen=set()
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as tf:
  for member in tf:
   assert member.isfile() and member.name not in seen;seen.add(member.name);data=tf.extractfile(member).read();assert len(data)==expected[member.name]['size_bytes'] and hashlib.sha256(data).hexdigest()==expected[member.name]['sha256']
 assert seen==set(expected)
 save(O/'manifest.json',{'scope':summary['scope'],'source_revision':summary['source_revision'],'archive':{'size_bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()},'parts':parts,'files':files,'summary':{'sha256':sha(O/'summary.json')},'raw':{'path':'raw.jsonl.gz','sha256':sha(O/'raw.jsonl.gz'),'uncompressed':{'path':'raw.jsonl','sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}},'verification':'All archive members round-trip verified; API key excluded and bytes scanned. Frozen source, runtime/model and prepared cache bindings verified. Full diagnostic census and rescored short correctness retained; necessary-window and full-duration workloads absent.'})
 (O/'README.md').write_text("# Startup CPU heap trim 009: FAIL; reclamation branch NO_RESULT\n\nThe second bounded startup reclamation experiment released 8,552 KiB of anonymous RSS before profiling and 544 KiB afterwards. Authenticated startup, the actual worker's frozen libc mapping and a 4,224-input-token correctness smoke passed. All 2,486 prepared kernel files stayed unchanged.\n\nThe host read one page from swap during the smoke. Used swap and swap-out counters stayed unchanged; GLM cgroup swap and memory-limit events remained zero. The fixed verdict is FAIL, so no necessary window or full-duration workload was admitted. The external census retains a simultaneous dockerd VmSwap decrease of 4 KiB and major-fault increase; this correlation does not establish causation or exempt the run from its gate.\n\nGLM stopped cleanly, memory recovered, and runtime/model, identity, default/proxy/guard checks passed. Neither bounded reclamation alternative reliably closed the host finding, so this startup-reclamation branch is NO_RESULT. No third allocator variant is proposed. Read-only daemon/timer observations after shutdown are diagnostic context, not qualification or changes to the services. The prior million-token result used a different configuration; this smoke is not a context, paired fidelity, durability or production performance result.\n")
 print(json.dumps({'verdict':summary['verdict'],'failed_checks':[k for k,v in checks.items() if not v],'archive_members':len(files),'archive_bytes':len(blob)}),flush=True)
if __name__=='__main__':main()
