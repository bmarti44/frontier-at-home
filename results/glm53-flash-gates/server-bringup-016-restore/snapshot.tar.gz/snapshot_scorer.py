import hashlib,io,json,re,subprocess,tarfile,time
from pathlib import Path
src=Path('/home/bmarti44/.cache/glm53-flash/server-bringup-016-restore');dst=Path('results/glm53-flash-gates/server-bringup-016-restore');dst.mkdir()
secret=(src/'api-key').read_bytes().strip();paths=[(p.name,p) for p in src.iterdir() if p.is_file() and p.name!='api-key']
paths += [('identity/'+str(p.relative_to(src/'identity')),p) for p in (src/'identity').rglob('*') if p.is_file()]
paths += [('lib/'+p.name,p) for p in (src/'lib').glob('*.py')]
crash,=Path('/home/bmarti44/.local/state/glm52-crashlog').glob('*-glm53-dev-1422846');paths += [('watchdog/'+p.name,p) for p in crash.iterdir() if p.is_file()]
paths += [('snapshot_scorer.py',Path(__file__))]
paths += [('feature_smoke.py',Path('results/glm53-flash-gates/bringup-harness/feature_smoke.py')),('first_response.py',Path('results/glm53-flash-gates/bringup-harness/first_response.py'))]
rows=[];captured={}
with tarfile.open(dst/'snapshot.tar.gz','w:gz') as archive:
 for name,p in paths:
  data=p.read_bytes();assert secret not in data
  captured[name]=data;row={'path':name,'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)};rows.append(row)
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
first=json.loads(captured['first-response-summary.json']); tool=json.loads(captured['tool-smoke-response.json'])['response']['choices'][0]
slots=[json.loads(captured[f'slot-{n}-response.json']) for n in range(2,6)]
checks={'authenticated_text':first['completed'] and first['answer']=='2 + 2 equals 4.', 'unauthenticated_rejected':first['authentication_rejection']==401,'tool_name_and_arguments':tool['finish_reason']=='tool_calls' and tool['message']['tool_calls'][0]['function']['name']=='get_weather' and json.loads(tool['message']['tool_calls'][0]['function']['arguments'])=={'city':'Paris'},'four_requests_completed':all(r['response']['choices'][0]['finish_reason']=='stop' and str(2*n) in r['response']['choices'][0]['message']['content'] for n,r in zip(range(2,6),slots)),'four_client_requests_overlap':max(r['start'] for r in slots)<min(r['end'] for r in slots)}
samples=captured['watchdog/samples.log'].decode();memory=[int(x) for x in re.findall(r'mem_avail_kb=(\d+)',samples)];swap=[int(x) for x in re.findall(r'cgroup_swap_current_bytes=(\d+)',samples)]
checks['memory_above_18_gib']=min(memory)>=18*1048576;checks['cgroup_swap_zero']=max(swap)==0
checks['same_api_key_as_008']=(src/'api-key').read_bytes()==Path('/home/bmarti44/.cache/glm53-flash/server-bringup-008/api-key').read_bytes()
for name,expected in [('image-smoke','red'),('images4-smoke','red, green, blue, yellow'),('video-smoke','blue')]:
 choice=json.loads(captured[name+'-response.json'])['response']['choices'][0]
 checks[name]=choice['finish_reason']=='stop' and expected in (choice['message'].get('content') or '').lower()
state=json.loads(subprocess.check_output(['scripts/52_engine_switch.sh','status','--json'],text=True));checks['qwen_default_unchanged']=state['active_profile']=='qwen38-1m'
summary={'scope':'basic serving smoke only; live process snapshot, not production qualification','verdict':'PASS' if all(checks.values()) else 'FAIL','snapshot_unix':time.time(),'checks':checks,'memory_low_gib':min(memory)/1048576,'memory_formula':'minimum externally sampled MemAvailable_kB / 1048576','cgroup_swap_peak_bytes':max(swap),'capacity':{'slots':4,'tokens_per_slot':262144,'aggregate_tokens':1048576,'full_context_tested':False},'media':'single image, four images and16-frame video smoke passed at224x224; larger media unqualified','recorded_switch_state':state,'performance':'not yet measured','server_lifecycle':'still running; watchdog remains active with 9000-second timeout'}
(dst/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');a=dst/'snapshot.tar.gz';(dst/'manifest.json').write_text(json.dumps({'archive':{'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'size_bytes':a.stat().st_size},'files':rows},indent=2)+'\n')
(dst/'README.md').write_text('''# GLM is serving text, tools, images and video: basic smoke PASS

The authenticated local API returned `2 + 2 equals 4.` and rejected an
unauthenticated model-list request with HTTP 401. A tool request produced
`get_weather` with `{"city":"Paris"}`. Four overlapping client requests all
completed with correct arithmetic answers. No external weather tool was invoked.

This working launch enables text/tools/images/video, 128-token prefill chunks, the standard
allocator, one-time warm-up cache cleanup, prepared attention/sampling libraries
and native attention tactics without autotuning. It retains four 262,144-token
slots and the explicit full cache. These are short serving checks; maximum
context and fidelity are not qualified. The separate context-direct-003 run failed
with a CUDA illegal access and Xid31; this restore does not resolve that fault. Single-image, four-image and16-frame video checks passed with224x224 fixtures. Larger media remain unqualified.

The archive is a consistent byte snapshot of individual files while the server
continues running; each file has its own hash. It includes requests, responses,
launcher code/configuration, identity observations and external memory samples.
It excludes the API key and reproducible warm caches. The terminal lifecycle
and clean shutdown have not been observed for this still-running attempt.
Qwen remains the recorded default. The test server has a 2.5-hour timeout.

See [the one-command launch guide](../../../docs/GLM53-QUICKSTART.md).
''')
assert all(checks.values()),summary
print(json.dumps(summary,indent=2))
