// Includes' hash value: 5a43a3d02d8a442188bc640fe4fc98d4

#include <deep_gemm/impls/sm120_fp8_paged_mqa_logits.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm120_fp8_paged_mqa_logits<
        1, 32, 128, 64, true, false,
        2, 3, 128, 128, 256, float
    >);
};
