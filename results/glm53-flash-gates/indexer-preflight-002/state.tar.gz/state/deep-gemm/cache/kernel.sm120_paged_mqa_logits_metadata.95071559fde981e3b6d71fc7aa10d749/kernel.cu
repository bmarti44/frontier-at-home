// Includes' hash value: 40bbf1b7bfa99ad23ea12f86382dd3a0

#include <deep_gemm/scheduler/sm120_paged_mqa_logits.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sched::sm120_paged_mqa_logits_metadata<
        32, 128, 48, false
    >);
};
