"""Tiny synthetic CPU falsifier only; never native BF16 reference measurements."""
from pathlib import Path
import hashlib,json,os,sys,time,traceback
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_HUB_KERNELS='0',CUDA_VISIBLE_DEVICES='',TOKENIZERS_PARALLELISM='false')
import torch
from safetensors.torch import save_file
from transformers.core_model_loading import revert_weight_conversion,convert_and_load_state_dict_in_model
from transformers.conversion_mapping import get_model_conversion_mapping
from transformers.modeling_utils import LoadStateDictConfig
from transformers.models.glm5_next.configuration_glm5_next import Glm5NextConfig,Glm5NextTextConfig,Glm5NextVisionConfig
from transformers.models.glm5_next.modeling_glm5_next import Glm5NextForConditionalGeneration
O=Path(sys.argv[1]);O.mkdir(exist_ok=False);torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.manual_seed(53001)
def native_json(value):
 if isinstance(value,set):return sorted(value)
 raise TypeError('Unsupported native evidence value: '+type(value).__name__)
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,allow_nan=False,default=native_json)+'\n')
def digest(t):return hashlib.sha256(t.detach().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
def rec(**r):
 with (O/'raw.jsonl').open('a') as f:f.write(json.dumps({'time_unix':time.time(),**r},allow_nan=False)+'\n')
def same(a,b,label):
 if a is None or b is None:assert a is b,label;return
 assert a.shape==b.shape and a.dtype==b.dtype and torch.isfinite(a).all() and torch.isfinite(b).all(),label
 assert torch.equal(a,b),label
 rec(kind='exact_tensor',label=label,shape=list(a.shape),dtype=str(a.dtype),sha256=digest(a))
try:
 tc=Glm5NextTextConfig(hidden_size=32,vocab_size=64,pad_token_id=0,num_hidden_layers=5,intermediate_size=64,moe_intermediate_size=16,n_routed_experts=12,num_experts_per_tok=2,n_shared_experts=1,n_group=1,topk_group=1,num_attention_heads=2,num_key_value_heads=2,q_lora_rank=8,kv_lora_rank=8,qk_nope_head_dim=8,qk_rope_head_dim=0,v_head_dim=8,index_head_dim=8,index_n_heads=2,index_kpool=4,index_topk=8,linear_head_dim=8,linear_num_heads=2,linear_conv_kernel_dim=4,hc_mult=4,hc_sinkhorn_iters=20,indexer_types=['full','full','full','full','shared'],use_cache=False)
 vc=Glm5NextVisionConfig(depth=1,hidden_size=16,num_heads=2,image_size=8,patch_size=2,spatial_merge_size=2,temporal_patch_size=2,out_hidden_size=32,intermediate_size=32,projection_intermediate_size=32)
 config=Glm5NextConfig(text_config=tc,vision_config=vc,image_token_id=60,video_token_id=61,image_start_token_id=56,image_end_token_id=57,video_start_token_id=58,video_end_token_id=59)
 config._attn_implementation='eager';tc._attn_implementation='eager';vc._attn_implementation='eager';config._experts_implementation='eager';tc._experts_implementation='eager'
 save('configuration.json',config.to_dict());model=Glm5NextForConditionalGeneration(config).eval()
 keep=model._keep_in_fp32_modules_strict
 expected={k:v.detach().to(torch.float32 if any(x in k.split('.') for x in keep) else torch.bfloat16).contiguous() for k,v in model.state_dict().items()}
 native=revert_weight_conversion(model,expected.copy())
 assert any('.experts.10.gate_proj.weight' in k for k in native)
 assert any('.q_conv1d.weight' in k for k in native)
 checkpoint=O/'synthetic-checkpoint';checkpoint.mkdir();config.save_pretrained(checkpoint)
 keys=sorted(native,reverse=True);index={};shards=[]
 for i in range(3):
  filename=f'model-{i+1:05d}-of-00003.safetensors';subset={k:native[k] for k in keys[i::3]};save_file(subset,str(checkpoint/filename),metadata={'format':'pt'});index.update({k:filename for k in subset});shards.append({'path':filename,'sha256':hashlib.sha256((checkpoint/filename).read_bytes()).hexdigest()})
 (checkpoint/'model.safetensors.index.json').write_text(json.dumps({'metadata':{'total_size':sum(v.numel()*v.element_size() for v in native.values())},'weight_map':index},indent=2)+'\n')
 del model
 model,info=Glm5NextForConditionalGeneration.from_pretrained(checkpoint,dtype=torch.bfloat16,attn_implementation='eager',experts_implementation='eager',use_kernels=False,local_files_only=True,output_loading_info=True)
 model.eval();save('loading-info.json',info)
 assert not any(info.get(k) for k in ['missing_keys','unexpected_keys','mismatched_keys','error_msgs']),info
 actual=model.state_dict();assert set(actual)==set(expected)
 for k in sorted(expected):same(actual[k],expected[k],'parameter:'+k)
 save('checkpoint-binding.json',{'shards':shards,'native_source_tensors':len(native),'loaded_parameters_and_buffers':len(actual),'keep_fp32':keep})
 with torch.device('meta'):partial=Glm5NextForConditionalGeneration(config).eval()
 all_keys=set(partial.state_dict())
 def load_stage(prefixes):
  raw={k:v.clone() for k,v in sorted(native.items(),reverse=True) if any(k.startswith(p) for p in prefixes)}
  want={k for k in all_keys if any(k.startswith(p) for p in prefixes)}
  cfg=LoadStateDictConfig(dtype=torch.bfloat16,dtype_plan=partial._get_dtype_plan(torch.bfloat16),device_map={'':'cpu'},weight_mapping=get_model_conversion_mapping(partial))
  information,offload=convert_and_load_state_dict_in_model(partial,raw,cfg)
  assert not offload
  got={k for k,v in partial.state_dict().items() if v.device.type!='meta'}
  assert got==want,(got-want,want-got)
  for k in sorted(want):same(partial.state_dict()[k],expected[k],'partial_parameter:'+k)
  rec(kind='partial_stage',prefixes=prefixes,loaded=len(got),untouched_meta=len(all_keys-got),loading_info=repr(information))
 text=model.model.language_model
 streamtext=partial.model.language_model
 with torch.inference_mode():
  cases=[torch.randint(1,55,(1,n)) for n in [5,64,65]];full=[];expected_layers={}
  for ci,ids in enumerate(cases):
   handles=[]
   for li,layer in enumerate(text.layers):
    def hook(module,args,result,ci=ci,li=li):expected_layers[ci,li]=(result[0].clone(),None if result[1] is None else result[1].clone())
    handles.append(layer.register_forward_hook(hook))
   full.append(model(input_ids=ids,use_cache=False).logits.clone())
   for handle in handles:handle.remove()
  # Visit each layer across all cases, retaining lossless hidden streams per case.
  load_stage(['model.language_model.embed_tokens.'])
  states=[streamtext.embed_tokens(ids).unsqueeze(2).expand(-1,-1,tc.hc_mult,-1).contiguous() for ids in cases];topks=[None]*len(cases)
  streamtext.embed_tokens.to_empty(device='meta')
  for li,layer in enumerate(streamtext.layers):
   load_stage([f'model.language_model.layers.{li}.'])
   for ci,ids in enumerate(cases):
    states[ci],topks[ci]=layer(states[ci],attention_mask=torch.ones_like(ids,dtype=torch.bool),position_ids=torch.arange(ids.shape[1]).unsqueeze(0),position_embeddings=None,input_ids=ids,past_key_values=None,prev_topk_indices=topks[ci])
    same(states[ci],expected_layers[ci,li][0],f'case{ci}:layer{li}:hidden_streams');same(topks[ci],expected_layers[ci,li][1],f'case{ci}:layer{li}:topk')
   layer.to_empty(device='meta')
  load_stage(['model.language_model.norm.','lm_head.'])
  for ci,state in enumerate(states):same(partial.lm_head(streamtext.norm(streamtext.hc_head(state))),full[ci],f'case{ci}:full_logits')
 save('summary.json',{'verdict':'PASS','scope':'Tiny synthetic CPU conversion and layer-major parity only; not native reference, model fidelity, GPU feasibility, context or speed','lengths':[5,64,65],'real_model_weights_loaded':False,'checkpoint_conversion_exact':True,'partial_stage_residency_exact':True,'loaded_parameter_count':len(actual),'layer_hidden_and_returned_topk_exact':True,'full_logits_exact':True})
except BaseException as e:
 rec(kind='failure',error=repr(e),traceback=traceback.format_exc());save('summary.json',{'verdict':'FAIL','scope':'Tiny synthetic CPU falsifier only','error':repr(e),'real_model_weights_loaded':False});raise
finally:
 save('source.json',{'path':str(Path(__file__)),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.executable,'torch':torch.__version__})
print((O/'summary.json').read_text(),flush=True)
