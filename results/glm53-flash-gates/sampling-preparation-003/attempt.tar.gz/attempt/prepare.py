import hashlib,json
from flashinfer.jit.sampling import gen_sampling_module
spec=gen_sampling_module()
spec.build_and_load()
p=spec.get_library_path()
print(json.dumps({'result':'prepared','path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':p.stat().st_size}),flush=True)
