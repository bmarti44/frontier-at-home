import ast,contextlib,hashlib,importlib.util,json,os,shutil,subprocess,sys,time,types
from pathlib import Path
root=Path(__file__).parent
source=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/bf16-one-layer-001/run.py')
test=source.with_name('test_probe.py');spec=importlib.util.spec_from_file_location('candidate_test',test);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
f=mod.Evidence();f.setUp();O=f.root
try:
 (O/'code/scripts').mkdir(parents=True);shutil.copyfile(source.with_name('probe.py'),O/'code/probe.py');(O/'code/scripts/38_guard_glm53_probe.py').write_text('# CPU binding fixture, never executed\n');(O/'inventory.json').write_text('{}')
 def sha256_file(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
 def strict_json(p):return json.loads(Path(p).read_text())
 def write(p,data):Path(p).write_text(json.dumps(data))
 def require(ok,message):
  if not ok:raise ValueError(message)
 baseline={'pswpin':0,'pswpout':0,'used_swap_kib':0,'available_kib':115*1024**2}
 m=strict_json(O/'manifest.json');m.update(source_revision='frozen-reference',safety={'minimum_start_gib':110,'kill_floor_gib':40,'timeout_seconds':600,'memory_high_gib':62,'memory_max_gib':64},broad_baseline=baseline,node='/not/executed',python=sys.executable,wrapper='/not/executed',tag='glm53-bf16-layer-001',environment={},runtime={'root':str(O),'inventory':str(O/'inventory.json')},frozen_at_unix=1,files=[{'path':str(p),'size_bytes':p.stat().st_size,'sha256':sha256_file(p)} for p in [O/'code/probe.py',O/'code/scripts/38_guard_glm53_probe.py']]);write(O/'manifest.json',m)
 r=strict_json(O/'randomness.json');r.update(verification='DRAND_BLS_RECEIPT_OK',publication_unix=30,frozen_at_unix=1,round=2,signature='fixture',previous_signature='fixture');write(O/'randomness.json',r)
 before={n:sha256_file(O/n) for n in ['manifest.json','randomness.json']}
 def capture(*args):
  changed=strict_json(O/'manifest.json');changed['source_revision']='mutated-during-capture';write(O/'manifest.json',changed)
  changed=strict_json(O/'randomness.json');changed['publication_unix']=0;write(O/'randomness.json',changed)
 ns=dict(Path=Path,O=O,hashlib=hashlib,importlib=importlib,json=json,os=os,sys=sys,time=time,strict_json=strict_json,sha256_file=sha256_file,require=require,write=write,host=lambda:baseline,inference_lock=lambda:contextlib.nullcontext({}),capture_wrapper=capture,score_host_observations=lambda *a:{'verdict':'PASS'},verify_inventory=lambda *a:None,subprocess=types.SimpleNamespace(run=lambda *a,**k:types.SimpleNamespace(returncode=0,stdout='DRAND_BLS_RECEIPT_OK\n',stderr='')))
 tree=ast.parse(source.read_text());selected=[n for n in tree.body if isinstance(n,ast.Assign) and n.lineno in (9,12) or isinstance(n,ast.With)]
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(source),'exec',optimize=0),ns)
 result=strict_json(O/'summary.json');assert result['verdict']=='PASS',result
 after={n:sha256_file(O/n) for n in before};assert all(before[n]!=after[n] for n in before)
 record={'scope':'New controller AST executed with mocked closed containment/host/BLS interfaces; actual candidate inner scorer and filesystem/hash checks. No workload executed.','source_sha256':sha256_file(source),'before':before,'after':after,'candidate_summary':result,'finding':'Controller returns PASS after manifest and randomness bytes change during capture.'}
 (root/'binding-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
finally:f.tearDown()
