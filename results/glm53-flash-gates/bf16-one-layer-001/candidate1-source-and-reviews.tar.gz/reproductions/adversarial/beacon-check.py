import ast,json,subprocess,time,hashlib
from pathlib import Path
root=Path('/home/bmarti44/.cache/glm53-flash/bf16-one-layer-001-adversarial-controls')
source=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/bf16-one-layer-001/run.py')
r=json.loads(Path('/home/bmarti44/.cache/glm53-flash/soak-freeze-013/randomness.json').read_text())
actual_publication=1595431050+(r['round']-1)*30
freeze=actual_publication+3600
r['frozen_at_unix']=freeze;r['publication_unix']=freeze+30
(root/'preknown-mutated-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
module=ast.parse(source.read_text());body=next(n for n in module.body if isinstance(n,ast.With)).body[0].body
checks=[]
for n in body:
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='require' and n.lineno in (19,21):checks.append(n)
def require(ok,message):
 if not ok:raise ValueError(message)
assert len(checks)==2
exec(compile(ast.Module(body=checks,type_ignores=[]),str(source),'exec'),{'r':r,'m':{'frozen_at_unix':freeze},'require':require})
verifier=Path('/home/bmarti44/spark-deepseek-v4-flash/scripts/103_verify_drand_receipt_bundle.mjs')
cmd=['/home/bmarti44/.nvm/versions/node/v22.22.2/bin/node',str(verifier),str(r['round']),r['randomness'],r['signature'],r['previous_signature']]
p=subprocess.run(cmd,env={'PATH':'/usr/bin:/bin','HOME':'/nonexistent'},capture_output=True,text=True,timeout=30)
assert p.returncode==0 and p.stdout=='DRAND_BLS_RECEIPT_OK\n'
result={'finding':'Old authentic beacon passes launch checks with an invented post-freeze publication timestamp.','actual_publication_unix':actual_publication,'test_freeze_unix':freeze,'claimed_publication_unix':r['publication_unix'],'real_bls_verifier_exit':p.returncode,'real_bls_verifier_stdout':p.stdout,'candidate_ordering_and_seed_assertions':'PASS despite preknown beacon','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(root/'beacon-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
