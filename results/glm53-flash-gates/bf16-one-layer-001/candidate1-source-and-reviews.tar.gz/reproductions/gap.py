from pathlib import Path
import importlib.util,json,hashlib,time
S=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/bf16-one-layer-001')
s=importlib.util.spec_from_file_location('submitted_tests',S/'test_probe.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t)
results=[]
for name in ['missing_phase_fields_and_selector','contradictory_zero_memory_and_host_swap','missing_input_digest','reordered_completion_before_gpu']:
 f=t.Evidence();f.setUp()
 try:
  if name=='contradictory_zero_memory_and_host_swap':
   for row in f.rows:
    if row['kind'] in ('weights_on_gpu','forward_complete'):row.update(cuda_allocated=0,cuda_reserved=0,cuda_peak_allocated=0,elapsed_seconds=-1,host={'available_kib':0,'pswpin':1,'pswpout':1,'used_swap_kib':1})
   f.raw()
  elif name=='missing_input_digest':
   p=f.out/'output.json';d=json.loads(p.read_text());del d['input']['sha256'];p.write_text(json.dumps(d))
  elif name=='reordered_completion_before_gpu':
   completion=f.rows.pop();f.rows.insert(0,completion);f.raw()
  result=t.p.score(f.root)
  assert result['verdict']=='PASS'
  results.append({'synthetic_mutation':name,'actual_scorer_verdict':result,'unexpected_acceptance':True})
 finally:f.tearDown()
out=Path('/home/bmarti44/.cache/glm53-flash/bf16-one-layer-001-gap-reproductions.json')
r={'scope':'Synthetic validator mutations only; no native weights, model or GPU. Original test fixture uses substituted one-tensor geometry.','created_unix':time.time(),'source':{'path':str(S/'probe.py'),'sha256':hashlib.sha256((S/'probe.py').read_bytes()).hexdigest()},'results':results}
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
