"""Separate observations after the frozen native controller is terminal."""
import json,subprocess,time
from pathlib import Path
O=Path.home()/'.cache/glm53-flash/bf16-one-layer-005'
assert (O/'summary.json').is_file()
with (O/'identity/raw.jsonl').open() as f:first=json.loads(next(f))
processes=subprocess.run(['ps','-eo','pid=,pgid=,args='],capture_output=True,text=True,check=True)
rows=[s for s in processes.stdout.splitlines() if int(s.split(None,2)[1])==first['pgid']]
m=dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())
guard=O/'identity/summary.json'
d={'time_unix':time.time(),'probe_pid':first['pid'],'probe_pgid':first['pgid'],'proc_pid_exists':Path('/proc',str(first['pid'])).exists(),'matching_process_group_rows':rows,'identity_summary_present':guard.exists(),'identity_samples':json.loads(guard.read_text())['identity_samples'] if guard.exists() else None,'available_kib':int(m['MemAvailable'].split()[0]),'SwapTotal_kib':int(m['SwapTotal'].split()[0]),'proc_swaps':Path('/proc/swaps').read_text()}
with (O/'post-terminal-observation.json').open('x') as f:json.dump(d,f,indent=2)
print(json.dumps(d),flush=True)
assert not d['proc_pid_exists'] and not rows and d['available_kib']>=110*1024**2 and d['SwapTotal_kib']==0
