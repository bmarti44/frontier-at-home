from pathlib import Path
import hashlib,json,time,urllib.request
B=Path.home()/'.cache/glm53-flash/kimi-corpus-001';O=B/'preparation-repair-002';O.mkdir(exist_ok=False)
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
prior=json.loads(json.loads((B/'preparation-repair-001/batch-07-response.json').read_text())['message']['content'])['cases']
short=[x for x in prior if len(x['prompt'])<500];assert [x['id'] for x in short]==['kimi-071','kimi-076']
payload={'model':'kimi-k3:cloud','stream':False,'think':False,'options':{'temperature':0.7,'num_predict':6000},
 'messages':[{'role':'user','content':'Expand these two synthetic numerical-task prompts into clear self-contained English tasks of at least 180 words each (at least 800 characters). Keep their IDs. Include all numerical data and precise output requirements. Do not solve the tasks. Return ONLY valid JSON: {"cases":[{"id":"kimi-071","prompt":"..."},{"id":"kimi-076","prompt":"..."}]}. Escape quotation marks inside strings or use backticks. No extra fields. Original prompts: '+json.dumps(short,ensure_ascii=False)}]}
write(O/'request.json',payload);started=time.time()
try:
 req=urllib.request.Request('http://127.0.0.1:11434/api/chat',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=300) as response:raw=response.read(4*1024**2+1)
 (O/'response.json').write_bytes(raw);assert len(raw)<=4*1024**2
 result=json.loads(raw);assert result.get('done') is True and result.get('done_reason')=='stop'
 fixed=json.loads(result['message']['content'])['cases'];assert [x['id'] for x in fixed]==['kimi-071','kimi-076']
 assert all(set(x)=={'id','prompt'} and 500<=len(x['prompt'])<=12000 for x in fixed)
 replacement={x['id']:x for x in fixed};categories=json.loads((B/'protocol.json').read_text())['categories']
 final=[];provenance=[]
 for i,category in enumerate(categories):
  if i in [4,8]:source=B/f'preparation-repair-001/batch-{i:02d}-normalized.json';cases=json.loads(source.read_text())['cases']
  elif i==7:source=B/'preparation-repair-001/batch-07-response.json';cases=[replacement.get(x['id'],x) for x in prior]
  else:source=B/f'batch-{i:02d}/response.json';cases=json.loads(json.loads(source.read_text())['message']['content'])['cases']
  assert [x['id'] for x in cases]==[f'kimi-{10*i+j:03d}' for j in range(10)]
  for case in cases:
   assert set(case)=={'id','prompt'} and 500<=len(case['prompt'])<=12000
   final.append({'id':case['id'],'category':category,'messages':[{'role':'user','content':case['prompt']}]})
   origin=O/'response.json' if case['id'] in replacement else source
   provenance.append({'id':case['id'],'response_source':str(origin.relative_to(B)),'source_sha256':hashlib.sha256(origin.read_bytes()).hexdigest(),'prompt_sha256':hashlib.sha256(case['prompt'].encode()).hexdigest()})
 assert len(final)==len({x['id'] for x in final})==len({x['messages'][0]['content'] for x in final})==100
 (O/'cases.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in final));write(O/'case-provenance.json',provenance)
 write(O/'summary.json',{'scope':'Unfrozen Kimi synthetic prompt preparation; no reference or model qualification','prepared_cases':100,'case_ids_unique':True,'prompt_texts_unique':True,'original_failed_batches_retained':True,'changed_cases':['kimi-071','kimi-076'],'started_unix':started,'ended_unix':time.time(),'bf16_reference_generated':False})
 print('100 distinct Kimi prompt candidates prepared; all original responses and failures retained.',flush=True)
except Exception as e:
 write(O/'failure.json',{'started_unix':started,'ended_unix':time.time(),'error':repr(e)});raise
