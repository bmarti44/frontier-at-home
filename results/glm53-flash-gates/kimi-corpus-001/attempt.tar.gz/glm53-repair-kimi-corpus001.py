from pathlib import Path
import hashlib,json,time,urllib.request
B=Path.home()/'.cache/glm53-flash/kimi-corpus-001'
O=B/'preparation-repair-001';O.mkdir(exist_ok=False)
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
write(O/'protocol.json',{'scope':'Repair unfrozen synthetic input preparation only; original failed batches remain unchanged',
 'batch04':'Retain every predeclared ID040-049 with identical prompt text; exclude unsolicited extra ID050 to prevent duplicate IDs',
 'batch08':'Retain all ten exact case objects; ignore unsolicited top-level _dummy metadata',
 'batch07':'Generate a fresh replacement batch for malformed JSON; preserve original response and failed attempt',
 'selection':'No GLM outputs or scores exist; all predeclared IDs are required and no performance/fidelity-based selection occurs'})
for index in [4,8]:
    original=json.loads((B/f'batch-{index:02d}/response.json').read_text())
    parsed=json.loads(original['message']['content']);expected=[f'kimi-{index*10+j:03d}' for j in range(10)]
    selected=[x for x in parsed['cases'] if x['id'] in expected]
    assert [x['id'] for x in selected]==expected
    write(O/f'batch-{index:02d}-normalized.json',{'cases':selected})
    write(O/f'batch-{index:02d}-provenance.json',{'original_response':{'sha256':hashlib.sha256((B/f'batch-{index:02d}/response.json').read_bytes()).hexdigest()},'all_selected_prompt_text_unchanged':True,'required_ids':expected,'excluded_case_ids':[x['id'] for x in parsed['cases'] if x['id'] not in expected],'excluded_top_level_fields':[k for k in parsed if k!='cases']})
request=json.loads((B/'batch-07/request.json').read_text())
request['messages'][0]['content']+=' Important JSON requirement: escape every quotation mark inside a string, or use backticks inside prompt text instead. Return exactly the ten requested IDs, and no additional fields. Your previous attempt was invalid JSON and has been retained separately; create a fresh complete batch.'
write(O/'batch-07-request.json',request);started=time.time()
try:
    req=urllib.request.Request('http://127.0.0.1:11434/api/chat',data=json.dumps(request).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=600) as response:data=response.read(8*1024**2+1)
    (O/'batch-07-response.json').write_bytes(data);assert len(data)<=8*1024**2
    result=json.loads(data);assert result.get('done') is True and result.get('done_reason')=='stop'
    parsed=json.loads(result['message']['content']);assert set(parsed)=={'cases'}
    assert [x['id'] for x in parsed['cases']]==[f'kimi-{i:03d}' for i in range(70,80)]
    assert all(set(x)=={'id','prompt'} and 500<=len(x['prompt'])<=12000 for x in parsed['cases'])
    write(O/'batch-07-normalized.json',parsed)
    write(O/'summary.json',{'scope':'Unfrozen synthetic fixture repair only','prepared':True,'started_unix':started,'ended_unix':time.time(),'bf16_reference_generated':False})
    print('Preparation repair complete; failed originals retained.',flush=True)
except Exception as e:
    write(O/'failure.json',{'started_unix':started,'ended_unix':time.time(),'error':repr(e)})
    raise
