"""Prepare 100 original prompts using the owner's Ollama cloud route, not GLM references."""
from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, time, urllib.request

ROOT=Path.home()/'.cache/glm53-flash/kimi-corpus-001'
BASE='http://127.0.0.1:11434'
CATEGORIES=['python_debugging','typescript_api_work','sql_and_data_processing','shell_and_configuration_review',
            'structured_extraction','tool_use_planning','technical_document_retrieval','numerical_reasoning',
            'multilingual_tasks','constraint_following']
def write(p,value):p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def get(endpoint):
    with urllib.request.urlopen(BASE+endpoint,timeout=15) as response:return json.loads(response.read())
def generate(index,category):
    d=ROOT/f'batch-{index:02d}';d.mkdir()
    instructions=(
      'Create exactly 10 original, independent, self-contained user prompts for evaluating a coding and reasoning assistant. '
      'These are synthetic fixture inputs, not benchmark results or answers. Do not solve them. '
      f'Category: {category}. Use distinct scenarios, names, data, and constraints, not copies of one template. '
      'Each prompt should be about 180-300 words (or equivalent code/data/Chinese text), with all necessary source snippets, '
      'tables, records, definitions, or tool descriptions embedded. They must need no internet, credentials, repository, '
      'or real tool execution. Use only harmless fictional data. Avoid well-known benchmark questions. '
      'For tool-use cases describe hypothetical read-only tools and request a plan or JSON tool call, not execution. '
      'For multilingual tasks use a mixture of English, Chinese, Spanish and French across cases. '
      'For numerical cases supply every value. For retrieval cases provide several records and distractors. '
      'Return ONLY one valid JSON object with key "cases", a list of exactly 10 objects. '
      'Each object must contain exactly "id" and "prompt"; IDs must be the ten strings '
      +json.dumps([f'kimi-{index*10+j:03d}' for j in range(10)])+'. '
      'No Markdown fences, commentary, solutions, expected answers, scores, or reference logits.')
    payload={'model':'kimi-k3:cloud','messages':[{'role':'user','content':instructions}],
             'stream':False,'think':False,'options':{'temperature':0.7,'num_predict':12000}}
    write(d/'request.json',payload)
    started=time.time();request=urllib.request.Request(BASE+'/api/chat',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(request,timeout=600) as response:
            body=response.read(8*1024**2+1)
            (d/'response.json').write_bytes(body)
            assert len(body)<=8*1024**2,'response limit exceeded'
            result=json.loads(body)
        assert result.get('done') is True and result.get('done_reason')=='stop', 'incomplete generation'
        content=result['message']['content'];(d/'content.txt').write_text(content)
        parsed=json.loads(content)
        assert type(parsed) is dict and set(parsed)=={'cases'} and type(parsed['cases']) is list
        cases=parsed['cases'];assert len(cases)==10
        assert [x.get('id') for x in cases]==[f'kimi-{index*10+j:03d}' for j in range(10)]
        for x in cases:
            assert set(x)=={'id','prompt'} and type(x['prompt']) is str and 500<=len(x['prompt'])<=12000
        write(d/'validation.json',{'prepared':True,'cases':10,'started_unix':started,'ended_unix':time.time(),
                                  'scope':'Prompt syntax/count only; not correctness, teacher references, or model qualification'})
        print(json.dumps({'event':'prepared','batch':index,'category':category,'cases':10}),flush=True)
        return [{'id':x['id'],'category':category,'messages':[{'role':'user','content':x['prompt']}]} for x in cases]
    except Exception as e:
        write(d/'failure.json',{'started_unix':started,'ended_unix':time.time(),'error':repr(e),'prepared':False})
        print(json.dumps({'event':'failed','batch':index,'error':repr(e)}),flush=True)
        raise

ROOT.mkdir(exist_ok=False)
tags=get('/api/tags');running=get('/api/ps')
write(ROOT/'ollama-tags-before.json',tags);write(ROOT/'ollama-ps-before.json',running)
route=next(m for m in tags['models'] if m['name']=='kimi-k3:cloud')
assert route['remote_host']=='https://ollama.com' and route['remote_model']=='kimi-k3' and route['size']<1024**2
assert not running['models']
write(ROOT/'protocol.json',{'scope':'100 Kimi-authored synthetic prompt candidates; not GLM BF16 reference data',
 'categories':CATEGORIES,'cases_per_category':10,'route':route,'source':{'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
 'candidate_selection':'Use every case after validation; no selection on GLM output or scores; freeze before later qualification',
 'cloud_limit':'The Ollama route digest is recorded; hosted model weight identity is not independently pinned'})
(ROOT/'generate.py').write_bytes(Path(__file__).read_bytes())
all_cases=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures={pool.submit(generate,i,c):i for i,c in enumerate(CATEGORIES)}
    for future in concurrent.futures.as_completed(futures):
        try:all_cases.extend(future.result())
        except Exception as e:errors.append({'batch':futures[future],'error':repr(e)})
all_cases.sort(key=lambda x:x['id'])
assert len({x['id'] for x in all_cases})==len(all_cases)
assert len({x['messages'][0]['content'] for x in all_cases})==len(all_cases)
(ROOT/'cases.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in all_cases))
write(ROOT/'ollama-ps-after.json',get('/api/ps'))
write(ROOT/'summary.json',{'scope':'Synthetic prompt preparation only','prepared_cases':len(all_cases),'expected_cases':100,
 'complete':not errors and len(all_cases)==100,'errors':errors,'bf16_reference_available':False,'model_qualification':'NO_RESULT'})
print(json.dumps({'event':'complete','prepared_cases':len(all_cases),'errors':errors}),flush=True)
