// Includes' hash value: dbb72e9506c830244a5dfe90a452e411

#include <deep_gemm/impls/sm120_fp8_mqa_logits.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm120_fp8_mqa_logits<
        32, 128, false,
        4, 128, 2, 3,
        48, 128, 256, float
    >);
};
