---
pretty_name: GLM-5.3-Flash BF16 Teacher Full-Vocabulary Logits
license: other
task_categories:
- text-generation
tags:
- glm-5.3
- logits
- kld
- shapleymcg
---

# GLM-5.3-Flash BF16 teacher logits

This dataset contains full-vocabulary float32 teacher logits from the immutable
`zai-org/GLM-5.3-Flash-BF16` revision `a6c167b62691b2bac901344b65cb651a70f53e43`.
It keeps the sealed final KLD panel qualification-only and publishes the
separate non-final calibration panel under role-specific paths.

- Qualification-only final windows: `25`
- Qualification-only final prediction positions: `51175`
- Vocabulary size: `154880`
- Teacher receipt: `2ae08117c3d4247f747b2a9a889b68e1a06387b788d56a0bf23bb950c77bc5a5`
- Token-panel receipt: `0beec5770e5107547731b084f1bc5f9fb8ba79d67af56ddb70d919da367737d5`
- Final-panel dataset manifest: `61faf80c9a8c7bb60bcefbfd6208c7f63609ddc4089798c2f317bfcabc8569a4`
- Non-final full-panel manifest: `8397ef9d3eedbb256d09f2166fdb3e337dde907fd7b710510bb293b7190c7917`

The original capture receipt, backend identity, per-window SHA-256 hashes, and
portable `dataset-manifest.json` are included. These are teacher targets, not a
quantized model and not evaluation results by themselves.

## Full non-final teacher-logit panel

The role-separated non-final logits are under `logits/full-panel/`:

- `fit/`: 384 windows
- `conditional-fit/`: 128 windows
- `selection/`: 64 windows
- `confirmation/`: 64 windows

Together these are 640 windows, 1,310,080 prediction positions, and
811,621,019,136 bytes of float32 full-vocabulary logits. No `final` window is
present in this tree. The 25 final windows remain only under
`logits/window-0000.safetensors` through `window-0024.safetensors` for
qualification.

`logits/full-panel/full-panel-manifest.json` binds all 640 payload paths,
sizes, SHA-256s, token hashes, attention-mask hashes, roles, and the seven
source batch manifests. Per-batch capture receipts and manifests are under
`logits/full-panel/receipts/batch-0000/` through `batch-0006/`.
`logits/full-panel/full-panel-hf-verification.json` records the independent
Hub verification of that aggregate at immutable revision `361c58fba46e439e38d7b43497fe23e87c5d69bf`.

## Replay token panel

The sealed token IDs needed to replay the logits are under
`calibration/panel-v1/`:

- `arrays/final-0000.tokens.npy` through `final-0024.tokens.npy`: the 25
  qualification-only windows paired with `logits/window-0000.safetensors`
  through `window-0024.safetensors`.
- `arrays/causal-mask-2048.npy`: the shared 2,048-position causal attention
  mask.
- `panel.json`, `panel.receipt.json`, `corpus.receipt.json`, and
  `tokenizer.receipt.json`: window metadata and immutable provenance.
- `arrays/fit-*.tokens.npy` and `arrays/selection-*.tokens.npy`: separate
  calibration fit and selection windows. `conditional-fit-*` and
  `confirmation-*` windows are also included as separately named roles.

Every token array has shape `(2048,)` and dtype `int32`. The final arrays must
remain qualification-only: do not use them for fitting, expert selection, or
quantizer tuning. The SHA-256 of each `.npy` file is recorded as
`token_ids_sha256` for its window in `panel.json`; the shared mask file SHA-256
is recorded as `attention_mask_sha256`.

## BF16 hidden and router calibration captures

The sealed calibration captures used by the uniform routed-expert campaigns
are also included. They contain no `final` rows: all 25 final windows remain
qualification-only.

- `calibration/main-ep4-full/`: 42 main routed layers, layers 3 through 44,
  over 640 separate `fit`, `conditional-fit`, `selection`, and `confirmation`
  windows. Each layer contains 1,310,720 BF16 hidden rows plus router top-8 IDs
  and applied FP32 router weights. `terminal/last_hidden.bf16.bin` preserves the
  terminal target-model state used for MTP replay.
- `calibration/mtp45-ep4-full/`: the standalone MTP layer-45 boundary over the
  same 640 calibration windows, with 1,310,080 scored rows and matching BF16
  hidden states, router top-8 IDs, and FP32 router weights.

For each capture, `capture-manifest.json` records byte counts and SHA-256s for
the raw payloads; `capture-receipt.json`, `backend.json`, `plan.json`, and
`progress.json` preserve the sealed model, panel, runtime, and execution
provenance. Payload layout and replay notes are documented in the README under
each capture directory.
