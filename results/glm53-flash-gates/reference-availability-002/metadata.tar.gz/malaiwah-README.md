---
license: mit
tags:
- glm5_next
- glm-5.3-flash
- fidelity
- kld
- hidden-states
x_fidelity:
  spec: https://github.com/malaiwah/glm53-flash-fidelity-suite/blob/main/docs/FIDELITY-DATASET-SPEC.md
  spec_version: fidelity-provenance/v1
  role: evidence
  description: >-
    Receipts, captures and stack provenance behind the published GLM-5.3-Flash
    fidelity numbers. Not itself a sealed fidelity dataset; the primary evidence
    for rows that are.
  contains:
    - sealed KLD receipts (reports/*.json)
    - engine launch logs (reports/engine-logs/) -- the falsifiable stack claim
    - stack provenance retro (reports/stack-provenance-retro.json)
    - clean-scope recompute (reports/clean-scope-recompute.json)
  registry:
    dataset: malaiwah/quant-fidelity-registry
    schema_version: quant-fidelity-registry/v1
  comparability_rules: https://github.com/malaiwah/glm53-flash-fidelity-suite/blob/main/WHAT-WE-MEASURE.md
---

# GLM-5.3-Flash Fidelity Suite v1

**Historical distribution-fidelity evidence for GLM-5.3-Flash** (released 2026-08-26):
BF16-reference and FP8-as-served hidden-state captures, a shared LM head, and
receipts from the declared capture/replay path. Compatible candidate captures
can be compared on matching published positions without holding the 643 GB
reference; this is not a universal native-serving or task-quality score. Protocol: the Qwen3.8-27B fidelity-suite v5 methodology
(hidden-state replay through one shared BF16 head, exact two-pass full-vocab KL).

## Publication correction — 2026-09-08

This card now distinguishes the historical full run from the public capture
subset and withdraws unsupported cross-lane ratios, replay-equivalence and
noise-bound claims. No measured value, sealed receipt, capture, head or digest
has changed. Old reports retain their original bytes and historical prose.

**Public scope:** each of `reference-bf16-shard0/` and `as-served-fp8-shard0/`
contains 512 contexts, not the full 5,120-context run below. Read each
`capture-manifest-shard.json` (`complete: false`) and `capture-cut-point.json`;
the original `capture-manifest-full.json` records the historical full run, not
current local availability. These captures are post-final-RMSNorm: apply the
head only, not final norm again. Public shard bytes alone cannot rederive the
full-run headline. Candidate captures are a separate prerequisite.

## Historical full-run FP8 vs BF16 replay measurements

| metric | value |
|---|---|
| token mean KLD | **0.028104 nats** |
| context macro mean (historical nominal 95% bootstrap interval) | 0.028104 [0.027205, 0.028982] |
| median / p99 / p999 KLD | 4.93e-03 / 3.54e-01 / 1.37e+00 |
| top-1 agreement | 0.9427 |
| mean JSD (bits) | 0.009201 |
| scored positions | 10,480,640 (5,120 contexts x 2,047) |

The interval above is retained from `reports/report-fp8-vs-bf16.json`, which
records 837 bootstrap clusters for 5,120 contexts. That count alone does not
establish independent-document sampling or population coverage. These are
fixed-corpus descriptive statistics, not deployment-population inference.
The historical Flash final25 panel discussed later is a different panel.

Per-stratum mean KLD:

| stratum | contexts | mean KLD |
|---|---|---|
| code | 1024 | 0.025320 |
| encyclopedic | 1024 | 0.022285 |
| literary | 1024 | 0.032324 |
| multilingual | 1024 | 0.025154 |
| scientific | 1024 | 0.035436 |

Restricted scored-position geometry (positions 1024+ only): token mean KLD 0.018794, top-1 0.9512. Matching geometry alone does not establish llama.cpp comparability; reference, tokens, vocabulary, scope and lane must also match.

## Receipts

- **BF16 live-vs-replayed**: mean KLD 1.49e-02, top-1 0.95695 over 8 contexts (`reports/qualify-bf16.json`). This measured discrepancy is not equality or proof that replay reproduces native-served logits.
- **bf16 determinism**: 20/32 sentinel contexts byte-identical across independent engine loads.
- **fp8 determinism**: 29/32 sentinel contexts byte-identical across independent engine loads.
- **Head equality**: FP8 repo lm_head/final-norm byte-identical to BF16: True/True. This supports the declared shared-head path, not equal hidden states, logits or padded probability mass; shared-head replay cannot assess a different candidate head's quantization error.

## Known issue: run-to-run nondeterminism (first report)

The day-one vLLM measurements observed cross-launch differences: 12/32 BF16
sentinel contexts differed bytewise in the reported pair, with mean replay KL
8.7e-4 / top-1 0.9946 (`reports/determinism-bf16.json` and
`reports/determinism-noise-bf16.json`). Within-launch repeatability was observed
under that configuration, not established universally. Live-vs-replay on a
separate launch measured ~1.5e-2 over 8 contexts (`reports/qualify-bf16.json`).
Neither value is a universal noise floor, additive error term or upper bound.

The initial Triton-autotune root-cause attribution and the proposed cache-only
"deterministic rerun" recipe are superseded by the intervention results below.
Kernel/collective differences were investigated, but the evidence does not
uniquely attribute the discrepancy or prove deterministic operation. Historical
discussion: https://github.com/vllm-project/vllm/pull/53906#issuecomment-5433635837 .
A shared replay path does not cancel all capture or serving differences; additional
perturbations may amplify or cancel divergence.

- **Cross-pipeline comparison**: vs brandonmusic/GLM-5.3-Flash-BF16-Teacher-Logits (separate pipeline, full-vocab fp32 logits): mean KLD(theirs||ours) 1.27e-02, top-1 0.96653 over 51,175 positions. This is a measured discrepancy, not independent reproduction of identical outputs.

## Pins

| what | value |
|---|---|
| BF16 reference | `zai-org/GLM-5.3-Flash-BF16` @ `b1967181a3917ae70a437f4884748f6b8e3a1f4d` |
| FP8 as-served | `zai-org/GLM-5.3-Flash` @ `3f1971b7b5f7a528c9c4ef6212c8785298a8c24a` |
| engine | vLLM glm53-flash docker image (digest in `reports/image-pin.txt`), TP8 H200, eager, TF32 off, BF16 KV |
| suite | 5,120 ctx x 2,048 tok, held-out v5-lineage corpus, GLM tokenizer, 0 calibration-contamination hits |
| contamination boundary | exllamav3 standard_cal_data @ 0c49587a |

## Contents

- `suite/` - tokens + manifest (partitions: analysis/qualification/sentinels)
- `reference-bf16-shard0/`, `as-served-fp8-shard0/` - 512 contexts x [2047, 4096] bf16 hidden states each
- `head/` - shared BF16 `lm_head` (154,880 x 4,096) + final norm + extraction receipt
- `reports/` - the KLD reports and every receipt above; `SHA256SUMS` covers all files

## Score your own quant

Capture final-norm hidden states of your quant over `suite/tokens/` (teacher-forced,
one context per forward), then replay against `reference-bf16-shard0` through
`head/head.safetensors` with the fidelity harness (tools published alongside;
see malaiwah's qwen38-27b-fidelity-suite-v5 for the protocol paper trail).

Produced autonomously on rented 8x H200; contact: malaiwah.

## Determinism interventions (receipts in reports/)

| configuration | sentinel pairs byte-identical |
|---|---|
| unpinned (3 independent pairs) | 20/32, 25/32, 20/32 |
| + single-config Triton autotune shim (verified active) | 20/32 |
| + VLLM_ALLREDUCE_USE_SYMM_MEM=0, NCCL Ring/Simple/1ch, CUBLAS_WORKSPACE_CONFIG | **31/32** |
| + VLLM_USE_DEEP_GEMM=0 | 28/32 |

The stack-pinned pair had the highest observed match count, but these few
pairs do not uniquely identify a cause or establish a general flip rate. The
single-config Triton intervention did not eliminate differences. Residual
sources remain unidentified. FP8-side receipts record live-vs-replay 2.51e-2 /
top-1 0.9414 over 8 contexts; the sentinel discrepancy is separately in
`reports/determinism-noise-fp8.json`, not a universal noise bound.


## Calibration-clean scope (added 2026-08-29)

[brandonmusic](https://huggingface.co/brandonmusic/GLM-5.3-Flash-tr3-4bpw/tree/main/eval/kld)
proposed a community protocol for quantization-fidelity measurement and ran a
**13-gram calibration-overlap scan** of his sealed 25-window panel against its own
calibration-role windows. One whole domain of the final windows shares **37-39%**
of its 13-grams with calibration material, despite the panel being clean at the
*document-hash* level. **Document-hash dedup is not enough.** He excluded that
domain, leaving a 17-window calibration-clean scope.

Every malaiwah number published on that panel used all 25 windows, so it carries the
same contamination. Recomputed on his clean scope from our own published per-window
arrays - no GPU, no re-measurement, arithmetic on already-public data:

| row | panel25 | clean17 | move |
|---|---:|---:|---:|
| K6 sealed | 0.013723 | 0.011677 | -14.91 % |
| K8 | 0.012384 | 0.010829 | -12.55 % |
| official FP8 | 0.020615 | 0.018665 | -9.46 % |
| BF16 floor (cross-stack) | 0.012712 | 0.010648 | -16.24 % |
| brandonmusic 4bpw | 0.024555 | 0.024949 | **+1.61 %** |

**Claim correction, 2026-09-08:** panel25 values remain unchanged, but the
former 1.50x -> 1.60x K6/FP8 headline mixed the sealed-ep8 checkpoint lane with
the cross-stack FP8 lane. It is withdrawn as a quality ratio. K8 is streaming;
brandonmusic's row is his separate stack. This table is a mixed-design inventory,
not a ranking. The reported 1.44% increase in FP8 excess over its cross-stack
control does not establish that subtraction is generally stable or causal.
Never substitute that control for the streaming control or mix panel scopes.

The final25 panel contains four source documents; clean17 contains three.
Window-level intervals and signs are not independent population evidence.
The report's historical paired contrasts also mix lanes; consult the corrected
[measurement semantics](https://github.com/malaiwah/quant-fidelity-suite/blob/main/WHAT-WE-MEASURE.md)
and model cards before using any contrast. Published means and report bytes stay
unchanged.

- [reports/clean-scope-recompute.json](reports/clean-scope-recompute.json) - full
  recompute: both scopes, BCa intervals, per-domain tables, paired comparisons, provenance.
  `sha256 822049d44d307631046b7a98a4ed6cbc223b7dd242d03be57f71436585a15780`
- [reports/clean-scope-recompute.md](reports/clean-scope-recompute.md) - the same,
  rendered as tables. `sha256 e6fbdc75c75ca6ecba95d4c934f38043cc38b4b92f1c95e97f3747b692a3bcc5`

Both are emitted by
[bin/emit_clean_scope_report.py](https://github.com/malaiwah/quant-fidelity-suite/blob/main/bin/emit_clean_scope_report.py)
from committed per-window data, so anyone can regenerate them. Hashes are given
here because the repo-root `SHA256SUMS` is the original v1-publish snapshot and
does not cover reports added after it.

The scan, the threshold and the finding are brandonmusic's. Working:
[PROTOCOL-ALIGNMENT.md](https://github.com/malaiwah/quant-fidelity-suite/blob/main/docs/PROTOCOL-ALIGNMENT.md).

## Related / follow-on work

- Published K6/K8 artifacts and their scoped fidelity evidence: [K6](https://huggingface.co/malaiwah/GLM-5.3-Flash-TR3-6bpw), [K8](https://huggingface.co/malaiwah/GLM-5.3-Flash-TR3-8bpw). Mixed-rate assembly needs its own measurement; shared-seed parts do not prove a fresh mixed-rate encode or native-forward equivalence.
- Native exllamav3 `glm5_next` port design: [`port/`](https://github.com/malaiwah/quant-fidelity-suite/tree/main/port).
- Calibration activations dataset: [malaiwah/GLM-5.3-Flash-calibration-activations-v1](https://huggingface.co/datasets/malaiwah/GLM-5.3-Flash-calibration-activations-v1).
