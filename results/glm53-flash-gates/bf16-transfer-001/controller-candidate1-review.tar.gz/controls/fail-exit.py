import ast,contextlib,hashlib,json,tempfile,types
from pathlib import Path
source=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/bf16-transfer-001/run.py');tree=ast.parse(source.read_text())
def require(ok,msg):
 if not ok:raise ValueError(msg)
with tempfile.TemporaryDirectory() as d:
 O=Path(d);(O/'manifest.json').write_text('{}');(O/'randomness.json').write_text('{}');host={'available_kib':0,'pswpin':0,'pswpout':0,'used_swap_kib':0}
 ns={'O':O,'m':{'unit':'synthetic-not-executed'},'p':types.SimpleNamespace(host=lambda:host,require=require),'inference_lock':contextlib.nullcontext,'digest':lambda path:hashlib.sha256(path.read_bytes()).hexdigest(),'bindings':lambda:None,'save':lambda path,value:path.write_text(json.dumps(value)),'observe':lambda unit:{'fields':{'MainPID':'0','ActiveState':'inactive','ControlGroup':''}},'time':types.SimpleNamespace(time=lambda:1),'json':json}
 exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.With) or n is tree.body[-1]],type_ignores=[]),str(source),'exec'),ns)
 assert json.loads((O/'controller-summary.json').read_text())['verdict']=='FAIL'
