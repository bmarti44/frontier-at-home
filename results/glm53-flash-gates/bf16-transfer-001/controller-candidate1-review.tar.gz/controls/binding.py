import ast,contextlib,hashlib,json,tempfile,types
from pathlib import Path
source=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/bf16-transfer-001/run.py');tree=ast.parse(source.read_text());program=compile(ast.Module(body=[next(x for x in tree.body if isinstance(x,ast.With))],type_ignores=[]),str(source),'exec')
with tempfile.TemporaryDirectory() as d:
 O=Path(d);(O/'code').mkdir();m={'unit':'synthetic-not-executed','python':'/not-executed','source_revision':'original-parsed'};(O/'manifest.json').write_text(json.dumps(m));(O/'randomness.json').write_text('{"seed":0}');(O/'raw.jsonl').write_text(''.join(json.dumps({'arm':x})+'\n' for x in 'ABBA'))
 before=hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest();state={'samples':0,'lock_released':False}
 @contextlib.contextmanager
 def lock():
  changed=dict(m,source_revision='replacement-before-lock');(O/'manifest.json').write_text(json.dumps(changed))
  try:yield
  finally:state['lock_released']=True
 def require(ok,message):
  if not ok:raise ValueError(message)
 h={'available_kib':115*1024**2,'pswpin':0,'pswpout':0,'used_swap_kib':0}
 class Child:
  returncode=0;calls=0
  def poll(self):self.calls+=1;return None if self.calls==1 else 0
  def wait(self):return 0
 def observe(unit):
  state['samples']+=1
  if state['samples']==1:return {'host':h,'fields':{'ActiveState':'active','MemoryHigh':str(512*1024**2),'MemoryMax':str(768*1024**2),'MemorySwapMax':'0','OOMPolicy':'kill','KillMode':'control-group'},'process':{'executable':m['python'],'cmdline':[m['python'],'-I','-B',str(O/'code/probe.py'),'--frozen',str(O),'']},'cgroup':{'memory.swap.current':'0','memory.events':'low 0\nhigh 0\nmax 0\noom 0\noom_kill 0'}}
  return {'host':h,'fields':{'MainPID':'0','ActiveState':'inactive','ControlGroup':''}}
 ns={'O':O,'m':m,'p':types.SimpleNamespace(host=lambda:h,require=require,score=lambda rows:{'verdict':'PASS'}),'inference_lock':lock,'digest':lambda path:hashlib.sha256(path.read_bytes()).hexdigest(),'bindings':lambda:None,'subprocess':types.SimpleNamespace(check_output=lambda *a,**k:'',Popen=lambda *a,**k:Child()),'save':lambda path,value:path.write_text(json.dumps(value)),'observe':observe,'time':types.SimpleNamespace(time=lambda:1,sleep=lambda x:None),'json':json}
 exec(program,ns);summary=json.loads((O/'controller-summary.json').read_bytes());assert summary['verdict']=='PASS';after=hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest();assert after!=before and m['source_revision']!=json.loads((O/'manifest.json').read_bytes())['source_revision']
 result={'scope':'Actual new controller AST; mocked transfer/scorer/unit interfaces to isolate parsed-document snapshot binding','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'controller_summary':summary,'parsed_manifest_source_revision':m['source_revision'],'recorded_manifest_source_revision':json.loads((O/'manifest.json').read_bytes())['source_revision'],'before_digest':before,'after_digest':after,'invocation_document_digest':json.loads((O/'invocation.json').read_bytes())['documents']['manifest.json']['sha256']}
out=Path(__file__).parent/'binding-result.json';out.write_text(json.dumps(result,indent=2)+'\n');print(out.read_text())
