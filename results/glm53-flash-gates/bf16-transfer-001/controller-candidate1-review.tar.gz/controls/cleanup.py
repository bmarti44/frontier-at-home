import ast,contextlib,hashlib,json,subprocess,tempfile,types
from pathlib import Path
source=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/bf16-transfer-001/run.py');tree=ast.parse(source.read_text());node=next(x for x in tree.body if isinstance(x,ast.With));program=compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec');results=[]
for kind in ['stop_timeout','wait_timeout']:
 with tempfile.TemporaryDirectory() as d:
  O=Path(d);(O/'code').mkdir();(O/'manifest.json').write_text('{}');(O/'randomness.json').write_text('{}')
  state={'lock_released':False,'alive':True,'stop_calls':0,'wait_calls':0,'observations':0}
  @contextlib.contextmanager
  def lock():
   try:yield
   finally:state['lock_released']=True
  def require(ok,message):
   if not ok:raise ValueError(message)
  def observe(unit):state['observations']+=1;raise TimeoutError('injected unit query timeout')
  def stop(*args,**kwargs):
   state['stop_calls']+=1
   if kind=='stop_timeout':raise subprocess.TimeoutExpired('systemctl stop',30)
   return types.SimpleNamespace(returncode=1)
  class Child:
   returncode=None
   def poll(self):return None
   def wait(self,**kw):state['wait_calls']+=1;raise subprocess.TimeoutExpired('child.wait',10)
  ns={'O':O,'m':{'unit':'synthetic-not-executed','python':'/not-executed'},'p':types.SimpleNamespace(host=lambda:{'available_kib':115*1024**2},require=require),'inference_lock':lock,'digest':lambda path:hashlib.sha256(path.read_bytes()).hexdigest(),'bindings':lambda:None,'subprocess':types.SimpleNamespace(check_output=lambda *a,**k:'',Popen=lambda *a,**k:Child(),run=stop),'save':lambda path,value:path.write_text(json.dumps(value)),'observe':observe,'time':types.SimpleNamespace(time=lambda:1,sleep=lambda x:None),'json':json}
  try:exec(program,ns)
  except BaseException as e:state['exception']=repr(e)
  assert state['lock_released'] and state['alive'] and state['observations']==1 and not (O/'terminal.json').exists()
  results.append({'case':kind,**state,'terminal_evidence_created':False})
out=Path(__file__).parent/'cleanup-result.json';out.write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Actual controller AST with synthetic external process/unit interfaces; no service/download performed','findings':results},indent=2)+'\n');print(out.read_text())
