"""Use the existing bounded header reader to size a possible native BF16 reference."""
from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,re,sys,time,urllib.request
R=Path('/home/bmarti44/spark-deepseek-v4-flash');B=Path.home()/'.cache/glm53-flash/bf16-local-feasibility-001'
O=B/'streaming-layout';O.mkdir(exist_ok=False)
source=R/'scripts/34_audit_glm53_model_layout.py'
spec=importlib.util.spec_from_file_location('closed_header_audit',source);api=importlib.util.module_from_spec(spec);sys.modules[spec.name]=api;spec.loader.exec_module(api)
meta=json.loads((B/'model-api.json').read_text());rev=meta['sha'];repo=meta['id']
url=f'https://huggingface.co/api/models/{repo}/revision/{rev}?blobs=true'
with urllib.request.urlopen(url,timeout=45) as response:blob=response.read(16*1024**2)
(O/'model-api-blobs.json').write_bytes(blob);full=json.loads(blob);assert full['sha']==rev
index=json.loads((B/'model.safetensors.index.json').read_text());entries={x['rfilename']:x for x in full['siblings']};names=sorted(set(index['weight_map'].values()))
headers={};errors=[]
with (O/'raw.jsonl').open('x') as raw,concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    jobs={pool.submit(api.shard_header,f'https://huggingface.co/{repo}/resolve/{rev}/{name}',entries[name],O/(name+'.header.json')):name for name in names}
    for job in concurrent.futures.as_completed(jobs):
        name=jobs[job]
        try:
            length,header=job.result();headers[name]=header
            row={'time_unix':time.time(),'file':name,'header_bytes':length,'header_sha256':hashlib.sha256((O/(name+'.header.json')).read_bytes()).hexdigest(),'shard_bytes':entries[name]['size'],'shard_sha256_expected':entries[name]['lfs']['sha256']}
        except Exception as e:
            row={'time_unix':time.time(),'file':name,'failure':repr(e)};errors.append(row)
        raw.write(json.dumps(row)+'\n');raw.flush()
assert not errors,errors
layers={};other={};total=0
for name,filename in index['weight_map'].items():
    tensor=headers[filename][name];size=tensor['data_offsets'][1]-tensor['data_offsets'][0];total+=size
    match=re.match(r'model\.language_model\.layers\.(\d+)\.',name)
    if match:layers[match[1]]=layers.get(match[1],0)+size
    else:other[name]=size
assert total==index['metadata']['total_size']
summary={'scope':'Metadata-only BF16 layer sizing; native streaming execution and equivalence NOT TESTED','model':repo,'revision':rev,'headers':len(headers),'total_tensor_bytes':total,'layer_bytes':layers,'largest_layer_bytes':max(layers.values()),'largest_shard_bytes':max(entries[n]['size'] for n in names),'other_tensor_bytes':sum(other.values()),'estimated_one_layer_plus_one_shard_bytes':max(layers.values())+max(entries[n]['size'] for n in names),'limitations':['Tensor residency only; activations, pinned staging, kernels, masks and CUDA workspaces excluded.','Stock Transformers checkpoint key conversion and exact native computation must be retained and verified.','Metadata geometry does not prove safe load, correct execution, fidelity or acceptable runtime.'],'reader':{'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},'weight_payload_downloaded':False}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
