import hashlib,json,shutil,subprocess,time
from pathlib import Path
R=Path('/home/bmarti44/spark-deepseek-v4-flash');B=Path('/home/bmarti44/.cache/glm53-flash');old=B/'context-freeze-002';out=B/'context-freeze-003';server=B/'server-bringup-015-context';out.mkdir();(out/'code/scripts').mkdir(parents=True)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
previous=json.loads((old/'manifest.json').read_text());changed={str(R/p) for p in ('scripts/48_probe_glm53_context.py','scripts/tests/test_glm53_context_probe.py')};review=R/'results/glm53-flash-gates/context-score-memory-001/review.json';assert sha(R/'scripts/48_probe_glm53_context.py')==json.loads(review.read_text())['scorer']['sha256'];seen=set()
for row in previous['files']:
 p=Path(row['path'])
 if str(p) in changed:seen.add(str(p));continue
 assert p.stat().st_size==row['size_bytes'] and sha(p)==row['sha256'],str(p)
assert seen==changed
for name,root in [('runtime',B/'native-runtime-002/runtime'),('model',B/'model-weights-001')]:
 for rel,want in json.loads((old/(name+'-identities.json')).read_text()).items():
  s=(root/rel).stat();assert [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]==want,(name,rel)
 shutil.copyfile(old/(name+'-identities.json'),out/(name+'-identities.json'))
for name in ('fetch-randomness.py','code/scripts/103_verify_drand_receipt_bundle.mjs'):shutil.copyfile(old/name,out/name)
shutil.copyfile(__file__,out/'freeze.py')
cache=[{'path':str(p.relative_to(server/'state')),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((server/'state').rglob('*')) if p.is_file()];(out/'kernel-cache-inventory.json').write_text(json.dumps({'schema_version':1,'files':cache},indent=2)+'\n')
paths=[Path(row['path']) for row in previous['files']]+[old/'manifest.json',review,server/'launch.json',server/'server.py',server/'guard.py',server/'launch-frozen.py',out/'freeze.py',out/'fetch-randomness.py',out/'code/scripts/103_verify_drand_receipt_bundle.mjs',out/'kernel-cache-inventory.json',out/'runtime-identities.json',out/'model-identities.json']+list((server/'lib').glob('*.py'))
files=[{'path':str(p),'sha256':sha(p),'size_bytes':p.stat().st_size} for p in dict.fromkeys(paths)]
m={'scope':'same model/runtime with reviewed bounded-memory context client; offline fixtures precede loading','source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'server_root':str(server),'files':files,'runtime_files_verified':previous['runtime_files_verified'],'model_files_verified':previous['model_files_verified'],'hash_basis':'fresh whole-file verification in context-freeze001; unchanged runtime/model identities revalidated in freezes002 and003','allowed_source_change':sorted(changed),'cache_files':len(cache),'frozen_at_unix':time.time()};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'frozen_at_unix':m['frozen_at_unix'],'cache_files':len(cache),'runtime_model_unchanged':True}),flush=True)
