"""Launch prepared serving inputs through the existing GLM containment wrapper."""
import json,os,subprocess,sys,time
from pathlib import Path
root=Path(sys.argv[1]).resolve();repo=Path('/home/bmarti44/spark-deepseek-v4-flash')
launch=json.loads((root/'launch.json').read_text());environment=launch['environment'];python=Path('/home/bmarti44/.cache/glm53-flash/native-runtime-002/runtime/bin/python3')
control={'HOME':'/home/bmarti44','USER':'bmarti44','LOGNAME':'bmarti44','LANG':'C.UTF-8','PATH':'/usr/bin:/bin','XDG_RUNTIME_DIR':'/run/user/1000','DBUS_SESSION_BUS_ADDRESS':'unix:path=/run/user/1000/bus','GLM_SAFE_RUN_AS_CURRENT_USER':'1','GLM_SAFE_MIN_START_GIB':'110','GLM_SAFE_KILL_FLOOR_GIB':'18','GLM_SAFE_MEMORY_HIGH_GIB':'92','GLM_SAFE_TIMEOUT_S':'9000','GLM_SAFE_DONE_DIGESTS':'1'}
command=['/usr/bin/bash',str(repo/'results/glm52-gates/harness/glm_cgroup_run.sh'),'--tag','glm53-context-'+str(os.getpid()),'--','/usr/bin/env','-i',*(k+'='+v for k,v in sorted(environment.items())),str(python),'-I','-B',str(root/'guard.py'),'--output',str(root/'identity'),'--',str(root/'server.py'),'--serve',str(root)]
with (root/'wrapper.log').open('x') as log:result=subprocess.run(command,env=control,stdout=log,stderr=subprocess.STDOUT)
(root/'exit.json').write_text(json.dumps({'exit_code':result.returncode,'time_unix':time.time()})+'\n')
raise SystemExit(result.returncode)
