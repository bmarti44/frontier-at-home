import importlib.util,hashlib,json
from pathlib import Path
from tokenizers import Tokenizer
from jinja2.sandbox import ImmutableSandboxedEnvironment
path=Path('/home/bmarti44/spark-deepseek-v4-flash/results/glm53-flash-gates/soak-native-001/run.py');spec=importlib.util.spec_from_file_location('api',path);api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
t=Tokenizer.from_file(str(api.probe.MODEL/'tokenizer.json'));template=ImmutableSandboxedEnvironment(trim_blocks=True,lstrip_blocks=True,extensions=['jinja2.ext.loopcontrols']).from_string((api.probe.MODEL/'chat_template.jinja').read_text())
a=api.probe.retrieval.build_request_artifacts(t,target=4138,seed_sha256=hashlib.sha256(f"{'0'*64}:soak-worker:1".encode()).hexdigest())
for pad in ['', ' x','x',' ', ' .','.', ' a','a','\n','\n x',' x x',' 0','0']:
 body=a['payload'];body['messages'][0]['content']=a['fixture']['text']+pad+api.preparation.INSTRUCTION
 s=template.render(messages=body['messages'],tools=[],add_generation_prompt=True,reasoning_effort='low',clear_thinking=True)
 print(json.dumps({'padding':pad,'actual_tokens':len(t.encode(s,add_special_tokens=False).ids)}),flush=True)
