"""Restore exact pinned bytecode after preserving the failed preparation."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback
R=Path('/home/bmarti44/spark-deepseek-v4-flash');B=Path('/home/bmarti44/.cache/glm53-flash')
O=B/'indexer-workspace-preparation-001';Q=B/'indexer-workspace-runtime-restoration-001';runtime=B/'native-runtime-002/runtime';source_root=B/'native-runtime-001/runtime'
sys.path.insert(0,str(R/'scripts/lib'))
from glm53_probe_capture import inference_lock
from glm53_contract import verify_inventory

def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def check(p,size,h):
 assert p.is_file() and not p.is_symlink() and p.stat().st_size==size and digest(p)==h,str(p)

with inference_lock():
 assert not Q.exists()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip().startswith('65cc5966')
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
 assert read(O/'summary.json')['verdict']=='FAIL'
 assert read(O/'operator-after.json')['available_kib']>=110*1024**2
 mem=dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())
 assert int(mem['MemAvailable'].split()[0])>=110*1024**2
 status=json.loads(subprocess.check_output([str(R/'scripts/93_profile_serve.sh'),'--profile','glm-5.3-flash/cuda-spark-128g-1m-experimental','status'],text=True));assert status['state']=='stopped'
 audit=read(O/'runtime-extras-accounting.json');sources=read(O/'runtime-original-bytecode-sources.json');inv=read(O/'metadata/runtime-inventory.json')
 assert len(audit['original_file_errors'])==149 and len(audit['extras'])==830 and sources['originals_missing']==0
 assert digest(O/'runtime-changed-bytecode.tar.gz')=='739d9690da1be2ff1f0a89c2fa2c15a42bccc02167a13b5f577f5cb1f97375ba'
 published=R/'results/glm53-flash-gates/indexer-workspace-preparation-001'
 for p in [published/'attempt.tar.gz.part00',published/'attempt.tar.gz.part01']:assert p.is_file()
 for row in audit['original_file_errors']:
  rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts and rel.suffix=='.pyc'
  check(runtime/rel,row['actual_size_bytes'],row['actual_sha256']);check(source_root/rel,row['expected']['size_bytes'],row['expected']['sha256'])
 for row in audit['extras']:
  rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts and rel.suffix=='.pyc'
  check(runtime/rel,row['size_bytes'],row['sha256'])
 Q.mkdir();shutil.copyfile(__file__,Q/'restore.py')
 save(Q/'before.json',{'time_unix':time.time(),'runtime':str(runtime),'source':str(source_root),'failed_attempt_commit':'65cc5966','acceptance':'Exact original61401-file inventory; no rebinding','accounting_sha256':digest(O/'runtime-extras-accounting.json'),'sources_sha256':digest(O/'runtime-original-bytecode-sources.json'),'profile_status':status})
 moved=[];restored=[];failure=None;verified=0
 try:
  for row in audit['original_file_errors']:
   rel=Path(row['path']);p=runtime/rel;q=Q/'changed'/rel;q.parent.mkdir(parents=True,exist_ok=True)
   check(p,row['actual_size_bytes'],row['actual_sha256']);assert not q.exists();os.replace(p,q)
   shutil.copy2(source_root/rel,p);check(p,row['expected']['size_bytes'],row['expected']['sha256']);restored.append(str(rel))
  for row in audit['extras']:
   rel=Path(row['path']);p=runtime/rel;q=Q/'extras'/rel;q.parent.mkdir(parents=True,exist_ok=True)
   check(p,row['size_bytes'],row['sha256']);assert not q.exists();os.replace(p,q);moved.append(str(rel))
  verified=len(verify_inventory(runtime,inv));assert verified==61401
 except BaseException as e:failure=repr(e);(Q/'traceback.log').write_text(traceback.format_exc())
 save(Q/'summary.json',{'verdict':'FAIL' if failure else 'PASS','time_unix':time.time(),'failure':failure,'original_inventory_sha256':digest(O/'metadata/runtime-inventory.json'),'verified_original_files':verified,'restored':restored,'quarantined_extras':moved,'original_attempt_verdict':'FAIL','model_started':False,'inventory_changed':False})
 print(json.dumps({'verdict':'FAIL' if failure else 'PASS','restored_originals':len(restored),'quarantined_extras':len(moved),'verified_original_files':verified,'failure':failure}),flush=True)
 if failure:raise SystemExit(1)
