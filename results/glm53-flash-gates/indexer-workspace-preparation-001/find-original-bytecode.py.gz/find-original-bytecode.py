"""Locate saved exact bytes only; never synthesize, replace or remove bytecode."""
import hashlib,json,stat,subprocess,time
from pathlib import Path
out=Path(__file__).resolve().parent;account=out/'runtime-extras-accounting.json';data=json.loads(account.read_bytes());expected={x['path']:x['expected'] for x in data['original_file_errors']};root=Path(data['runtime_root'])
search=[Path('/home/bmarti44/.cache/glm53-flash'),Path('/home/bmarti44/.local/share/uv/python'),Path('/home/bmarti44/.cache/uv')]
by_key={}
for name,row in expected.items():by_key.setdefault((Path(name).name,row['size_bytes']),[]).append(name)
started=time.time();command=['rg','--files','-uu','-g','*.pyc',*[str(x) for x in search if x.is_dir()]];result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0,result.stderr
matches={name:[] for name in expected};tested=0;errors=[]
for text in result.stdout.splitlines():
    p=Path(text)
    if p.is_relative_to(root):continue
    try:
        info=p.lstat();names=by_key.get((p.name,info.st_size),[])
        if not names or not stat.S_ISREG(info.st_mode):continue
        with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
        after=p.lstat();assert (info.st_ino,info.st_dev,info.st_mtime_ns,info.st_ctime_ns,info.st_size)==(after.st_ino,after.st_dev,after.st_mtime_ns,after.st_ctime_ns,after.st_size)
        tested+=1
        for name in names:
            if h==expected[name]['sha256']:matches[name].append({'source_path':str(p),'sha256':h,'size_bytes':info.st_size,'mtime_ns':info.st_mtime_ns,'device':info.st_dev,'inode':info.st_ino})
    except Exception as e:errors.append({'path':str(p),'error':repr(e)})
found=[{'path':name,'expected':expected[name],'sources':sources} for name,sources in matches.items() if sources];missing=[expected[name] for name,sources in matches.items() if not sources]
receipt={'scope':'Read-only exact existing bytecode backup search; no regeneration or restoration','started_at_unix':started,'completed_at_unix':time.time(),'originals_required':149,'originals_found':len(found),'originals_missing':len(missing),'matching_sources':found,'missing':missing,'search_roots':list(map(str,search)),'candidate_pyc_paths':len(result.stdout.splitlines()),'candidate_files_hashed':tested,'search_errors':errors,'prior_quarantine_scope':'bf16-one-layer-001-bytecode-quarantine preserved only48 then-unlisted files; separate copies searched by exact expected SHA and size','archive_search_pending':bool(missing),'runtime_modified':False}
(out/'runtime-original-bytecode-sources.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'found':len(found),'missing':len(missing),'candidate_files_hashed':tested,'errors':errors,'missing_examples':missing[:5],'source_examples':found[:2]},indent=2))
