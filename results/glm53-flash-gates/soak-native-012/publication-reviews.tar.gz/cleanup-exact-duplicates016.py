from pathlib import Path
import fcntl, hashlib, io, json, os, subprocess, tarfile, time
R=Path('/home/bmarti44/spark-deepseek-v4-flash'); B=Path.home()/'.cache/glm53-flash'
D=R/'results/glm53-flash-gates/soak-native-012'; F=B/'soak-freeze-013/prepared-state'
def sha(data):return hashlib.sha256(data).hexdigest()
lock=open('/run/lock/frontier-at-home/inference.lock');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert subprocess.check_output(['git','status','--short'],cwd=R)==b''
m=json.loads((D/'manifest.json').read_text())
assert subprocess.check_output(['git','show','HEAD:results/glm53-flash-gates/soak-native-012/manifest.json'],cwd=R)==(D/'manifest.json').read_bytes()
for name in ['soak-native-012-publication-adversarial-review.json','soak-native-012-publication-gap-review.json']:
    assert (B/name).is_file()
status=subprocess.check_output(['scripts/93_profile_serve.sh','--profile','glm-5.3-flash/cuda-spark-128g-1m-experimental','status'],cwd=R,text=True)
assert json.loads(status)['state']=='stopped'
listeners=subprocess.check_output(['ss','-ltnp','( sport = :8015 )'],text=True);assert ':8015' not in listeners
assert not (B/'soak-native-012-observations/running-record.json').exists()
mem=Path('/proc/meminfo').read_text();available=int(next(x.split()[1] for x in mem.splitlines() if x.startswith('MemAvailable:')));assert available>=110*1024**2
blob=(D/m['archive']['path']).read_bytes();assert len(blob)==m['archive']['size_bytes'] and sha(blob)==m['archive']['sha256']
expected={x['path']:x for x in m['files']}; seen=set();targets=[]
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as t:
    for entry in t:
        assert entry.isfile() and entry.name not in seen;seen.add(entry.name)
        data=t.extractfile(entry).read();meta=expected[entry.name]
        assert len(data)==meta['size_bytes'] and sha(data)==meta['sha256']
        prefix='freeze/prepared-state/'
        if entry.name.startswith(prefix):
            p=F/entry.name[len(prefix):]
            assert p.is_file() and not p.is_symlink() and p.read_bytes()==data
            targets.append((p,meta))
assert seen==set(expected) and len(targets)==2486
assert {p for p in F.rglob('*') if p.is_file()}=={p for p,_ in targets}
assert not any(p.is_symlink() for p in F.rglob('*'))
before=os.statvfs(R); reclaimed=sum(x['size_bytes'] for _,x in targets)
for p,_ in targets:p.unlink()
for p in sorted([p for p in F.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.rmdir()
F.rmdir();after=os.statvfs(R)
receipt={'time_unix':time.time(),'scope':'Exact duplicate prepared cache from unloaded attempt012; committed and independently reviewed archive retained','archive':m['archive'],'all_archive_members_verified':len(seen),'deleted_files':len(targets),'deleted_bytes':reclaimed,'deleted_root':str(F),'available_before_bytes':before.f_bavail*before.f_frsize,'available_after_bytes':after.f_bavail*after.f_frsize,'inference_lock_held':True,'profile_status':json.loads(status),'listeners':listeners,'mem_available_kib':available,'files':[{'path':str(p),'archive_path':x['path'],'size_bytes':x['size_bytes'],'sha256':x['sha256']} for p,x in targets],'source':{'sha256':sha(Path(__file__).read_bytes())}}
(B/'verified-exact-duplicate-cleanup-016.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['files','listeners']}))
