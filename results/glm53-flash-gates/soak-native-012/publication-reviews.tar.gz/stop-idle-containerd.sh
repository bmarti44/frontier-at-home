exec 9</run/lock/frontier-at-home/inference.lock
flock -n 9
verify_services() {
    test "$(systemctl show docker.service -p ActiveState --value)" = inactive
    test "$(systemctl show docker.socket -p ActiveState --value)" = inactive
    test "$(systemctl show containerd.service -p MainPID --value)" = 2120
    test "$(awk '{print $22}' /proc/2120/stat)" = 1002
    test "$(systemctl show containerd.service -p InvocationID --value)" = 67c0d0a5eed647148a596752d5d046cb
}
verify_services
namespaces=$(timeout 30s ctr namespaces list -q)
while IFS= read -r ns; do
    [ -n "$ns" ] || continue
    tasks=$(timeout 30s ctr --namespace "$ns" tasks list -q)
    [ -z "$tasks" ] || { echo "Running tasks in $ns; containerd left active."; exit 1; }
done <<< "$namespaces"
verify_services
systemctl stop containerd.service
